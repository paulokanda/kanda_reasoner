# send to ai when freezing feature

Use this file when a feature, module, prompt box, script, workflow, UI box, delivery system, or project baseline is finished and you want another AI to freeze it correctly.

This is the practical version.

## what to send to ai

Send these files first:

```text
project_freeze_ledger/readme_project_freeze_ledger.md
project_freeze_ledger/project_frozen_implemented_steps.md
```

If the feature touches a box that is already frozen, also send the relevant entry from:

```text
project_freeze_ledger/entries/
```

## copy and paste this prompt to ai

```text
Freeze this implemented box.

Read these freeze ledger files first:
- project_freeze_ledger/readme_project_freeze_ledger.md
- project_freeze_ledger/project_frozen_implemented_steps.md

If I provide an existing freeze entry from project_freeze_ledger/entries/, use it as boundary context.

Box name:
[paste box name]

Frozen version:
[paste version or baseline]

What was implemented:
[paste short summary]

Validation evidence:
[paste terminal validation output]

Behavioral tests:
[paste behavior tests if relevant]

User acceptance:
[paste acceptance, for example: user approved after validation]

Do-not-touch boundaries:
[paste known boundaries, or infer and propose them]

Task:
1. Decide whether this is freeze-worthy.
2. If freeze-worthy, create one new detailed freeze entry in project_freeze_ledger/entries/.
3. Update project_freeze_ledger/project_frozen_implemented_steps.md.
4. Update project_freeze_ledger/readme_project_freeze_ledger.md only if the freeze protocol itself changed or a practical workflow reference must be added.
5. Do not modify project logic.
6. Do not create a JSON mirror yet.
7. Do not invent validation.
8. Return a ZIP patch that contains only the needed project_freeze_ledger files and install/validate scripts.
```

## what ai must return

AI should return a ZIP patch with only freeze ledger updates, for example:

```text
project_freeze_ledger/project_frozen_implemented_steps.md
project_freeze_ledger/readme_project_freeze_ledger.md
project_freeze_ledger/entries/freeze-yyyymmdd-box-name-version.md
install_*.ps1
validate_*.ps1
```

If `readme_project_freeze_ledger.md` did not need changes, AI should say so and may omit it.

## practical rule

Most freezes need only two updates:

```text
1. project_freeze_ledger/project_frozen_implemented_steps.md
2. project_freeze_ledger/entries/freeze-yyyymmdd-box-name-version.md
```

The README changes only when the freeze process itself changes.

## one-line command

When in doubt, say:

```text
Freeze this implemented box using project_freeze_ledger. Update the master Markdown and create one detailed entry. Return a ZIP patch. Do not modify project logic.
```
