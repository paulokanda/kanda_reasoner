#!/usr/bin/env python3
"""
check_protected_paths.py

Checks whether proposed paths touch frozen protected paths.

Scope:
- Works inside <project_root>/project_freeze_ledger.
- Reads project_freeze_ledger/freeze_index.json.
- Uses freeze_index.json as a fast index only.
- If a path is protected, AI must read the detailed Markdown freeze entry.
- Does not modify files.
- Does not regenerate freeze_index.json.
- Uses Python standard library only.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple


INDEX_REL = Path("project_freeze_ledger/freeze_index.json")
DRIVE_RE = re.compile(r"^[A-Za-z]:[\\/]")


def find_project_root(start: Path) -> Path:
    current = start.resolve()
    if current.is_file():
        current = current.parent

    while True:
        if (current / "project_freeze_ledger").is_dir():
            return current
        if current.parent == current:
            raise FileNotFoundError("Could not find project_freeze_ledger from current path.")
        current = current.parent


def normalize_slashes(value: str) -> str:
    return value.replace("\\", "/").strip()


def strip_project_root_placeholder(value: str) -> str:
    normalized = normalize_slashes(value)

    changed = True
    while changed:
        changed = False
        for prefix in ["<project_root>/", "./"]:
            if normalized.startswith(prefix):
                normalized = normalized[len(prefix):]
                changed = True

    return normalized.strip("/")


def path_to_project_relative(raw_path: str, project_root: Path) -> Tuple[str, str | None]:
    original = raw_path.strip()

    if not original:
        return "", "empty input path"

    normalized = normalize_slashes(original)

    if normalized.startswith("<project_root>/") or normalized.startswith("./"):
        return strip_project_root_placeholder(normalized), None

    if DRIVE_RE.match(original) or original.startswith("/") or original.startswith("\\"):
        try:
            absolute = Path(original).resolve()
            root = project_root.resolve()
            relative = absolute.relative_to(root)
            return normalize_slashes(str(relative)), None
        except Exception:
            return normalized.strip("/"), "absolute path is not clearly inside detected project root"

    return normalized.strip("/"), None


def load_index(project_root: Path) -> Dict[str, Any]:
    index_path = project_root / INDEX_REL

    if not index_path.exists():
        raise FileNotFoundError(
            "Missing project_freeze_ledger/freeze_index.json. "
            "Run project_freeze_ledger/freeze_tools/build_freeze_index.py --sync first."
        )

    try:
        data = json.loads(index_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"freeze_index.json is invalid JSON: {exc}") from exc

    if data.get("schema_version") != "1.0":
        raise ValueError("freeze_index.json schema_version must be 1.0")

    freezes = data.get("freezes")
    if not isinstance(freezes, list):
        raise ValueError("freeze_index.json must contain a freezes list")

    return data


def is_folder_protection(protected_path: str) -> bool:
    return protected_path.endswith("/")


def path_matches(input_path: str, protected_path: str) -> bool:
    normalized_input = input_path.strip("/")
    normalized_protected = protected_path.strip("/")

    if is_folder_protection(protected_path):
        return (
            normalized_input == normalized_protected
            or normalized_input.startswith(normalized_protected + "/")
        )

    return normalized_input == normalized_protected


def check_paths(index: Dict[str, Any], input_paths: List[str], project_root: Path) -> Tuple[List[Dict[str, str]], List[str], List[str]]:
    matches: List[Dict[str, str]] = []
    warnings: List[str] = []
    normalized_inputs: List[str] = []

    for raw_path in input_paths:
        normalized_path, warning = path_to_project_relative(raw_path, project_root)
        if normalized_path:
            normalized_inputs.append(normalized_path)
        if warning:
            warnings.append(f"{raw_path}: {warning}")

    for freeze in index.get("freezes", []):
        if not isinstance(freeze, dict):
            continue

        status = str(freeze.get("status", ""))
        if status != "frozen":
            continue

        freeze_id = str(freeze.get("freeze_id", ""))
        entry = str(freeze.get("entry", ""))
        protected_paths = freeze.get("protected_paths", [])

        if not isinstance(protected_paths, list):
            continue

        for input_path in normalized_inputs:
            for protected_path_raw in protected_paths:
                protected_path = normalize_slashes(str(protected_path_raw))
                if path_matches(input_path, protected_path):
                    matches.append(
                        {
                            "input_path": input_path,
                            "matched_protected_path": protected_path,
                            "freeze_id": freeze_id,
                            "entry": entry,
                        }
                    )

    return matches, warnings, normalized_inputs


def print_result(matches: List[Dict[str, str]], warnings: List[str], normalized_inputs: List[str]) -> int:
    if warnings:
        print("WARNINGS:")
        for warning in warnings:
            print(f"- {warning}")
        print("")

    print("INPUT PATHS CHECKED:")
    for path in normalized_inputs:
        print(f"- {path}")

    print("")

    if matches:
        print("PROTECTED: yes")
        print("")
        print("Matched frozen boundaries:")

        seen = set()
        for match in matches:
            key = (
                match["freeze_id"],
                match["entry"],
                match["matched_protected_path"],
                match["input_path"],
            )
            if key in seen:
                continue
            seen.add(key)

            print(f"- Freeze ID: {match['freeze_id']}")
            print(f"  Entry file: {match['entry']}")
            print(f"  Matched protected path: {match['matched_protected_path']}")
            print(f"  Input path: {match['input_path']}")

        print("")
        print("REQUIRED ACTION:")
        print("- Read the listed detailed freeze entry before proposing changes.")
        print("- Do not rely only on freeze_index.json.")
        print("- If multiple entries match, read all matched entries.")
        return 0

    print("PROTECTED: no")
    print("No frozen protected path matched.")
    return 0


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Check whether proposed paths touch frozen protected paths."
    )
    parser.add_argument(
        "--project-root",
        default="",
        help="Optional project root. If omitted, auto-detect from current folder.",
    )
    parser.add_argument(
        "--paths",
        nargs="+",
        required=True,
        help="One or more paths to check. Use project-root-relative paths when possible.",
    )

    args = parser.parse_args(argv)

    try:
        if args.project_root:
            project_root = Path(args.project_root).resolve()
        else:
            project_root = find_project_root(Path.cwd())

        index = load_index(project_root)
        matches, warnings, normalized_inputs = check_paths(index, args.paths, project_root)

        print("PROJECT_ROOT", project_root)
        print("INDEX", (project_root / INDEX_REL))
        print("")

        return print_result(matches, warnings, normalized_inputs)

    except Exception as exc:
        print("PROTECTED: unknown")
        print("CHECK FAILED")
        print(str(exc))
        print("")
        print("REQUIRED ACTION:")
        print("- Run build_freeze_index.py --sync and --check, or send all freeze entries to AI.")
        print("- If the relevant detailed freeze entry is missing, ask the user for it.")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
