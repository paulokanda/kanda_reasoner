$ErrorActionPreference = "Stop"

param(
    [string]$ZipPath = "",
    [string]$TargetDir = ""
)

function Find-ProjectRoot {
    param([string]$StartDir)

    $current = Resolve-Path $StartDir
    while ($true) {
        $hasLedger = Test-Path (Join-Path $current "project_freeze_ledger")
        $hasPromptWorkspace = Test-Path (Join-Path $current "kanda_prompt_workspace")

        if ($hasLedger -and $hasPromptWorkspace) {
            return $current.Path
        }

        $parent = Split-Path $current -Parent
        if ([string]::IsNullOrWhiteSpace($parent) -or ($parent -eq $current.Path)) {
            throw "Could not auto-detect project root. Run this from the project root or pass -TargetDir."
        }

        $current = Resolve-Path $parent
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($TargetDir)) {
        $TargetDir = Find-ProjectRoot -StartDir (Get-Location).Path
    }

    if ([string]::IsNullOrWhiteSpace($ZipPath)) {
        $candidate = Join-Path $TargetDir "kanda_project_freeze_ledger_v17_dynamic_paths.zip"
        if (Test-Path $candidate) {
            $ZipPath = $candidate
        }
        else {
            throw "ZipPath not provided and ZIP not found in project root: $candidate"
        }
    }

    if (-not (Test-Path $ZipPath)) {
        throw "ZIP not found: $ZipPath"
    }

    $ledgerDir = Join-Path $TargetDir "project_freeze_ledger"
    if (-not (Test-Path $ledgerDir)) {
        throw "project_freeze_ledger not found under project root: $TargetDir"
    }

    $guidePath = Join-Path $ledgerDir "USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md"

    if (Test-Path $guidePath) {
        $backupDir = Join-Path $ledgerDir "_backups\user_read_freeze_guide_v17_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
        Copy-Item $guidePath (Join-Path $backupDir "USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md")
        Write-Host "Backup saved in:"
        Write-Host $backupDir
    }

    Expand-Archive -Path $ZipPath -DestinationPath $TargetDir -Force

    if (-not (Test-Path $guidePath)) {
        throw "USER_READ freeze guide was not installed."
    }

    Write-Host "INSTALL OK"
    Write-Host "Project root:"
    Write-Host $TargetDir
    Write-Host "Updated:"
    Write-Host $guidePath
    Write-Host "Terminal will clear in 5 seconds because install succeeded."
    Start-Sleep -Seconds 5
    Clear-Host
}
catch {
    Write-Host ""
    Write-Host "INSTALL FAILED"
    Write-Host $_.Exception.Message
    Write-Host "Terminal was not cleared because install failed."
    throw
}
