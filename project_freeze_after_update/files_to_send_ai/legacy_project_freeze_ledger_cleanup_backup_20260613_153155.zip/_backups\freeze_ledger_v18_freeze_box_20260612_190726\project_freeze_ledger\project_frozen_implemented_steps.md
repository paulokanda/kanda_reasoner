# project frozen implemented steps

Project: `kanda_reasoner`

Ledger version: `1.1`

Canonical source: this Markdown ledger plus detailed files in `entries/`.

JSON mirror: deferred until a validation/generation script exists.

## current frozen baselines

| freeze id | date | project box | status | detailed entry |
|---|---:|---|---|---|
| `freeze-20260612-phase7a-v24` | 2026-06-12 | `kanda_prompt_workspace/startup_delivery_system` | frozen operational baseline | `entries/freeze-20260612-phase7a-v24.md` |
| `freeze-20260612-project-freeze-ledger-v1` | 2026-06-12 | `project_freeze_ledger` | installed + validated project-wide freeze baseline | `entries/freeze-20260612-project-freeze-ledger-v1.md` |

## active do-not-touch summary

### startup delivery system

Frozen baseline:

```text
freeze-20260612-phase7a-v24
```

Do not casually change:

```text
kanda_prompt_workspace/prompt_tools/sync_startup_routing_kernel_pack.py
kanda_prompt_workspace/prompt_tools/STARTUP_ROUTING_KERNEL_SOURCES.json
kanda_prompt_workspace/first_AI_deliver/first_prompts_to_ai.zip
kanda_prompt_workspace/first_AI_deliver/send_this_first__CERT_<date>.md
kanda_prompt_workspace/first_AI_deliver/send_ai_just_if_modify_startup_delivery.md
```

Core invariant:

```text
maps first, not all prompts
```

Startup delivery invariant:

```text
first_prompts_to_ai.zip contains stable 00_START_HERE_FOR_AI.md
certificate data stays in file content and manifest
send_ai_just_if_modify_startup_delivery.md stays outside the normal startup ZIP
governed startup-delivery changes require the maintenance file before implementation
```

### project freeze ledger

Frozen baseline:

```text
freeze-20260612-project-freeze-ledger-v1
```

Do not casually change:

```text
project_freeze_ledger/readme_project_freeze_ledger.md
project_freeze_ledger/project_frozen_implemented_steps.md
project_freeze_ledger/entries/
```

Freeze ledger invariant:

```text
one master dashboard + one detailed entry per meaningful frozen baseline
all paths lower case
Markdown is canonical in v1
no manually maintained JSON mirror until a validator/generator exists
```

## next allowed project step

After this self-freeze entry is installed and validated, the next design step may be:

```text
design item 15: send_to_ai_if_requested/
```

Do not implement item 15 until the user explicitly approves that next phase.

## entries

### freeze-20260612-phase7a-v24

Summary:

```text
Phase 7A startup prompt request kernel delivery was implemented, validated, behavior-tested in fresh Chat B, repaired to v2.4, and frozen.
```

Detailed entry:

```text
project_freeze_ledger/entries/freeze-20260612-phase7a-v24.md
```

### freeze-20260612-project-freeze-ledger-v1

Summary:

```text
The project-wide freeze ledger v1 was created as a lower-case, Markdown-only, folder-based freeze box and validated as installed/readable.
```

Detailed entry:

```text
project_freeze_ledger/entries/freeze-20260612-project-freeze-ledger-v1.md
```

## update notes

When a new freeze is added, update this master ledger and create exactly one detailed entry file for that freeze.

Do not create a freeze entry for trivial micro-commits. Freeze only closed boxes or meaningful baselines.

## practical freeze workflow helper

Use this file when asking AI to freeze a completed feature:

project_freeze_ledger/send_to_ai_when_freezing_feature.md

Practical workflow:

1. send/read project_freeze_ledger/readme_project_freeze_ledger.md
2. send/read project_freeze_ledger/project_frozen_implemented_steps.md
3. send/read relevant existing entry if touching a frozen box
4. paste validation evidence
5. ask AI to update project_frozen_implemented_steps.md
6. ask AI to create one new entry in project_freeze_ledger/entries/
7. ask AI to return a ZIP patch
