# project freeze ledger

## purpose

This folder is the project-wide freeze box for `kanda_reasoner`.

It records implemented project parts that became frozen baselines after validation and/or human approval.

This is not only for prompts. It covers the complete project, including prompt workspace, prompt library, scripts, generated delivery files, validators, app architecture, UI boxes, workflow files, and future modules.

## v1 structure

```text
project_freeze_ledger/
  readme_project_freeze_ledger.md
  project_frozen_implemented_steps.md
  entries/
    freeze-20260612-phase7a-v24.md
    freeze-20260612-project-freeze-ledger-v1.md
```

## canonical rule

In v1, Markdown is the canonical source.

There is no manually maintained JSON mirror in v1. A JSON mirror may be added later only if generated or validated by a script, to avoid drift between Markdown and JSON.

## what counts as a freeze

A freeze is allowed when a closed project box has:

```text
1. clear scope
2. known files/folders affected
3. validation evidence
4. behavioral/user acceptance if relevant
5. do-not-touch boundaries
6. next allowed step
7. human approval when the change affects governance/canon/baseline architecture
```

Install success is not validation.

Validation success can make routine implementation eligible for freeze, but governance/canon changes still require human approval.

## freeze tiers

```text
tier 2: operational implementation freeze
- local implementation passed validation
- may be prepared by AI
- should be marked pending human acknowledgement unless user explicitly approves

tier 1: governance/canon/baseline freeze
- affects project rules, architecture, prompt canon, routing, delivery, or freeze policy
- requires human approval before being marked frozen
```

## update protocol after each future freeze

For every new freeze:

```text
1. confirm the implementation belongs to a closed box
2. confirm validation passed
3. confirm behavioral/user acceptance if relevant
4. assign a unique freeze id
5. update project_frozen_implemented_steps.md
6. create one detailed entry in entries/
7. record validation evidence summary
8. state do-not-touch boundaries
9. state external AI sharing rule
10. state next allowed step
```

## freeze id format

Use lower-case IDs:

```text
freeze-yyyymmdd-boxname-version
```

Examples:

```text
freeze-20260612-phase7a-v24
freeze-20260612-project-freeze-ledger-v1
```

## how future AI should read this box

For project governance, implementation, refactor, audit, validation, freeze, or handoff work, future AI should first request/read:

```text
project_freeze_ledger/readme_project_freeze_ledger.md
project_freeze_ledger/project_frozen_implemented_steps.md
```

Then, if the task touches a frozen box, request/read only the relevant file from:

```text
project_freeze_ledger/entries/
```

Do not assume all historical freeze entries are loaded unless they are actually provided.

## external AI sharing levels

Every freeze entry should include an exposure classification and an external AI sharing rule.

Suggested levels:

```text
safe_for_design_review
safe_for_targeted_ai_upload
internal_only
full_project_private
contains_sensitive_material
```

## do-not-touch principle

A frozen baseline is not unchangeable forever, but it cannot be changed casually.

To change a frozen baseline:

```text
1. identify the freeze entry
2. state why the baseline must change
3. use break-glass / rollback strategy if present
4. request the required prompt/card/context
5. implement the smallest safe patch
6. validate
7. create a new freeze entry or mark the old one superseded
```
