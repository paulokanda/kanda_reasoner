$ErrorActionPreference = "Stop"

param(
    [string]$TargetDir = ""
)

function Find-ProjectRoot {
    param([string]$StartDir)

    $current = Resolve-Path $StartDir
    while ($true) {
        $hasLedger = Test-Path (Join-Path $current "project_freeze_ledger")
        $hasPromptWorkspace = Test-Path (Join-Path $current "kanda_prompt_workspace")

        if ($hasLedger -and $hasPromptWorkspace) {
            return $current.Path
        }

        $parent = Split-Path $current -Parent
        if ([string]::IsNullOrWhiteSpace($parent) -or ($parent -eq $current.Path)) {
            throw "Could not auto-detect project root. Run this from the project root or pass -TargetDir."
        }

        $current = Resolve-Path $parent
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($TargetDir)) {
        $TargetDir = Find-ProjectRoot -StartDir (Get-Location).Path
    }

    Set-Location $TargetDir

    $guidePath = ".\project_freeze_ledger\USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md"

    Write-Host "STEP 1 - Required file"

    if (-not (Test-Path $guidePath)) {
        throw "Missing project_freeze_ledger\USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md"
    }

    Write-Host "OK: $guidePath"

    Write-Host ""
    Write-Host "STEP 2 - Confirm dynamic path instructions"

    $text = Get-Content $guidePath -Raw

    $requiredPhrases = @(
        "<project_root>",
        "Do not hardcode",
        "project may later be compiled",
        "project_freeze_ledger/readme_project_freeze_ledger.md",
        "project_freeze_ledger/project_frozen_implemented_steps.md",
        "project_freeze_ledger/send_to_ai_when_freezing_feature.md",
        "project_freeze_ledger/entries/",
        "Return a ZIP patch",
        "Do not modify project logic.",
        "hardcode local absolute paths"
    )

    foreach ($phrase in $requiredPhrases) {
        if ($text -notmatch [regex]::Escape($phrase)) {
            throw "Guide missing required phrase: $phrase"
        }
    }

    $forbiddenPhrases = @(
        "E:\kanda_reasoner\project_freeze_ledger\readme_project_freeze_ledger.md",
        "E:\kanda_reasoner\project_freeze_ledger\project_frozen_implemented_steps.md",
        "E:\kanda_reasoner\project_freeze_ledger\send_to_ai_when_freezing_feature.md"
    )

    foreach ($phrase in $forbiddenPhrases) {
        if ($text -match [regex]::Escape($phrase)) {
            throw "Guide still contains hardcoded path: $phrase"
        }
    }

    Write-Host "Guide now uses dynamic project-root paths."

    Write-Host ""
    Write-Host "STEP 3 - Confirm referenced files exist under detected root"

    $referencedFiles = @(
        ".\project_freeze_ledger\readme_project_freeze_ledger.md",
        ".\project_freeze_ledger\project_frozen_implemented_steps.md",
        ".\project_freeze_ledger\send_to_ai_when_freezing_feature.md",
        ".\project_freeze_ledger\entries"
    )

    foreach ($path in $referencedFiles) {
        if (-not (Test-Path $path)) {
            throw "Referenced path does not exist: $path"
        }
        Write-Host "OK: $path"
    }

    Write-Host ""
    Write-Host "VALIDATION OK"
    Write-Host "USER_READ freeze guide now uses dynamic project-root paths."
    Write-Host "Detected project root:"
    Write-Host $TargetDir
    Write-Host ""
    Write-Host "Press Enter twice to clear terminal."
    Read-Host
    Read-Host
    Clear-Host
}
catch {
    Write-Host ""
    Write-Host "VALIDATION FAILED"
    Write-Host $_.Exception.Message
    Write-Host "Terminal was not cleared because validation failed."
    throw
}
