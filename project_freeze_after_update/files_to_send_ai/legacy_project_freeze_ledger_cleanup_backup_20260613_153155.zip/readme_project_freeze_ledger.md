# project freeze ledger

## purpose

This folder is the project-wide freeze box for `kanda_reasoner`.

It records implemented project parts that became frozen baselines after validation and/or human approval.

This is not only for prompts. It covers the complete project, including prompt workspace, prompt library, scripts, generated delivery files, validators, app architecture, UI boxes, workflow files, and future modules.

## current structure

```text
project_freeze_ledger/
  USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md
  readme_project_freeze_ledger.md
  project_frozen_implemented_steps.md
  send_to_ai_when_freezing_feature.md
  entries/
    freeze-20260612-phase7a-v24.md
    freeze-20260612-project-freeze-ledger-v1.md
    freeze-20260612-project-freeze-ledger-v18.md
  freeze_tools/
    validate_freeze_entry_frontmatter.py
```

## file roles

```text
USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md
= human-facing manual

send_to_ai_when_freezing_feature.md
= reusable AI-facing freeze helper

project_frozen_implemented_steps.md
= master freeze dashboard

entries/
= one detailed freeze entry per meaningful frozen baseline

freeze_tools/validate_freeze_entry_frontmatter.py
= validator for structured freeze entry frontmatter
```

## canonical rule

In v1.x, Markdown remains canonical.

The detailed entries in `project_freeze_ledger/entries/*.md` are the source of truth for frozen boundaries.

There is no manually maintained JSON mirror in v1.x. A JSON mirror may be added later only if generated or validated by a script, to avoid drift between Markdown and JSON.

## structured entry rule

Every freeze entry must start with a strict YAML-like frontmatter block.

The frontmatter is intentionally simple and must be parseable by Python standard library code only.

Required fields:

```text
schema_version
freeze_id
box
status
date
freeze_tier
entry
protected_paths
do_not_touch_summary
superseded_by
```

Allowed status values:

```text
frozen
superseded
draft
```

Path rules:

```text
1. protected paths must be project-root-relative
2. no local absolute paths are allowed
3. folder protected paths must end with /
4. exact file paths should include their extension
5. use / as separator inside frontmatter
```

Example frontmatter:

```text
---
schema_version: 1.0
freeze_id: freeze-20260612-project-freeze-ledger-v18
box: project_freeze_ledger
status: frozen
date: 2026-06-12
freeze_tier: tier1-governance-baseline
entry: project_freeze_ledger/entries/freeze-20260612-project-freeze-ledger-v18.md
protected_paths:
  - project_freeze_ledger/readme_project_freeze_ledger.md
  - project_freeze_ledger/project_frozen_implemented_steps.md
  - project_freeze_ledger/entries/
do_not_touch_summary:
  - Do not reintroduce hardcoded local absolute paths.
  - Keep human guide and AI helper separate.
superseded_by:
---
```

## dynamic path rule

Do not hardcode local machine paths into freeze guides, freeze helpers, entries, or validation scripts.

Use project-root-relative paths or the placeholder:

```text
<project_root>
```

The project root is the folder that contains:

```text
project_freeze_ledger/
kanda_prompt_workspace/
```

This keeps the freeze ledger compatible with future compilation, relocation, zipped restore, and installation in a different folder.

## what counts as a freeze

A freeze is allowed when a closed project box has:

```text
1. clear scope
2. known files/folders affected
3. validation evidence
4. behavioral/user acceptance if relevant
5. do-not-touch boundaries
6. next allowed step
7. human approval when the change affects governance/canon/baseline architecture
```

Install success is not validation.

Validation success can make routine implementation eligible for freeze, but governance/canon changes still require human approval.

## how future AI should read this box

For project governance, implementation, refactor, audit, validation, freeze, or handoff work, future AI should first request/read:

```text
project_freeze_ledger/readme_project_freeze_ledger.md
project_freeze_ledger/project_frozen_implemented_steps.md
project_freeze_ledger/send_to_ai_when_freezing_feature.md
```

Then, if the task touches a frozen box, request/read the relevant file from:

```text
project_freeze_ledger/entries/
```

If relevance is unclear, request/read all entries.

Do not assume all historical freeze entries are loaded unless they are actually provided.

## do-not-touch principle

A frozen baseline is not unchangeable forever, but it cannot be changed casually.

To change a frozen baseline:

```text
1. identify the freeze entry
2. read the structured frontmatter and the human-readable entry body
3. state why the baseline must change
4. use break-glass / rollback strategy if present
5. implement the smallest safe patch
6. validate
7. create a new freeze entry or mark the old one superseded
```

## future automation note

The structured frontmatter is the prerequisite for later tools:

```text
build_freeze_index.py
check_protected_paths.py
files_needed_for_freezing.py --paths
```

Do not implement these later tools until the structured entries validator has passed.
