#!/usr/bin/env python3
"""
build_freeze_index.py

Builds and checks project_freeze_ledger/freeze_index.json.

Scope:
- Works only inside <project_root>/project_freeze_ledger.
- Reads structured frontmatter from project_freeze_ledger/entries/*.md.
- Treats Markdown entries as canonical source.
- Generates freeze_index.json as a derived artifact.
- Does not create protected path checker.
- Does not modify freeze entries.
- Uses Python standard library only.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Any


SCHEMA_VERSION = "1.0"
CANONICAL_SOURCE = "project_freeze_ledger/entries/*.md"
GENERATOR = "project_freeze_ledger/freeze_tools/build_freeze_index.py"
INDEX_REL_PATH = Path("project_freeze_ledger/freeze_index.json")
MASTER_REL_PATH = Path("project_freeze_ledger/project_frozen_implemented_steps.md")
ENTRIES_REL_DIR = Path("project_freeze_ledger/entries")

REQUIRED_FIELDS = [
    "freeze_id",
    "box",
    "status",
    "date",
    "entry",
    "protected_paths",
    "do_not_touch_summary",
    "superseded_by",
]

VALID_STATUS = {"frozen", "superseded", "draft"}
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
DRIVE_RE = re.compile(r"[A-Za-z]:[\\/]")
FREEZE_ID_RE = re.compile(r"freeze-\d{8}-[a-z0-9][a-z0-9-]*")


def find_project_root(start: Path) -> Path:
    current = start.resolve()
    if current.is_file():
        current = current.parent

    while True:
        if (current / "project_freeze_ledger").is_dir():
            return current
        if current.parent == current:
            raise FileNotFoundError("Could not find project_freeze_ledger from current path.")
        current = current.parent


def parse_scalar(raw: str) -> str:
    value = raw.strip()
    if value == "null":
        return ""
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        return value[1:-1].replace('\\"', '"')
    return value


def parse_frontmatter(text: str, file_path: Path) -> Dict[str, object]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")

    if not normalized.startswith("---\n"):
        raise ValueError(f"{file_path.name}: missing opening frontmatter delimiter")

    end = normalized.find("\n---\n", 4)
    if end == -1:
        raise ValueError(f"{file_path.name}: missing closing frontmatter delimiter")

    block = normalized[4:end].splitlines()
    data: Dict[str, object] = {}
    current_list_key: str | None = None

    for line_number, line in enumerate(block, start=2):
        stripped = line.strip()

        if not stripped:
            continue

        if stripped.startswith("- "):
            if current_list_key is None:
                raise ValueError(f"{file_path.name}:{line_number}: list item without list key")
            item = parse_scalar(stripped[2:])
            data[current_list_key].append(item)  # type: ignore[index]
            continue

        if ":" not in line:
            raise ValueError(f"{file_path.name}:{line_number}: invalid frontmatter line: {line}")

        key, raw_value = line.split(":", 1)
        key = key.strip()
        raw_value = raw_value.strip()

        if raw_value == "":
            data[key] = []
            current_list_key = key
        else:
            data[key] = parse_scalar(raw_value)
            current_list_key = None

    return data


def normalize_rel_path(path: str) -> str:
    return path.replace("\\", "/")


def validate_path_is_relative(path: str, field: str, entry_name: str) -> None:
    if not path:
        raise ValueError(f"{entry_name}: empty path in {field}")

    if DRIVE_RE.search(path):
        raise ValueError(f"{entry_name}: drive-letter absolute path forbidden in {field}: {path}")

    if path.startswith("/") or path.startswith("\\"):
        raise ValueError(f"{entry_name}: absolute path forbidden in {field}: {path}")

    if ".." in Path(path).parts:
        raise ValueError(f"{entry_name}: parent traversal forbidden in {field}: {path}")


def load_entry(project_root: Path, entry_file: Path) -> Dict[str, Any]:
    text = entry_file.read_text(encoding="utf-8")

    if DRIVE_RE.search(text):
        raise ValueError(f"{entry_file.name}: drive-letter absolute path found in entry text")

    data = parse_frontmatter(text, entry_file)

    for field in REQUIRED_FIELDS:
        if field not in data:
            raise ValueError(f"{entry_file.name}: missing required field: {field}")

    freeze_id = str(data["freeze_id"])
    expected_filename = f"{freeze_id}.md"

    if entry_file.name != expected_filename:
        raise ValueError(
            f"{entry_file.name}: freeze_id must match filename. Expected filename: {expected_filename}"
        )

    status = str(data["status"])
    if status not in VALID_STATUS:
        raise ValueError(f"{entry_file.name}: invalid status: {status}")

    date = str(data["date"])
    if not DATE_RE.match(date):
        raise ValueError(f"{entry_file.name}: invalid date format: {date}")

    entry_path = normalize_rel_path(str(data["entry"]))
    validate_path_is_relative(entry_path, "entry", entry_file.name)

    expected_entry_path = f"project_freeze_ledger/entries/{entry_file.name}"
    if entry_path != expected_entry_path:
        raise ValueError(f"{entry_file.name}: entry field must be {expected_entry_path}")

    if not (project_root / entry_path).exists():
        raise ValueError(f"{entry_file.name}: entry path does not exist: {entry_path}")

    protected_paths = data["protected_paths"]
    if not isinstance(protected_paths, list) or not protected_paths:
        raise ValueError(f"{entry_file.name}: protected_paths must be a non-empty list")

    normalized_protected_paths: List[str] = []
    for protected_path in protected_paths:
        normalized = normalize_rel_path(str(protected_path))
        validate_path_is_relative(normalized, "protected_paths", entry_file.name)
        normalized_protected_paths.append(normalized)

    do_not_touch_summary = data["do_not_touch_summary"]
    if not isinstance(do_not_touch_summary, list) or not do_not_touch_summary:
        raise ValueError(f"{entry_file.name}: do_not_touch_summary must be a non-empty list")

    superseded_by_raw = str(data["superseded_by"])
    superseded_by = superseded_by_raw if superseded_by_raw else None

    if status == "superseded" and not superseded_by:
        raise ValueError(f"{entry_file.name}: superseded status requires superseded_by")

    if status != "superseded" and superseded_by:
        raise ValueError(f"{entry_file.name}: superseded_by should be null unless status is superseded")

    return {
        "freeze_id": freeze_id,
        "box": str(data["box"]),
        "status": status,
        "date": date,
        "entry": entry_path,
        "protected_paths": normalized_protected_paths,
        "do_not_touch_summary": [str(item) for item in do_not_touch_summary],
        "superseded_by": superseded_by,
    }


def load_freezes(project_root: Path) -> List[Dict[str, Any]]:
    entries_dir = project_root / ENTRIES_REL_DIR
    if not entries_dir.is_dir():
        raise FileNotFoundError("Missing project_freeze_ledger/entries folder")

    entry_files = sorted(entries_dir.glob("*.md"))
    if not entry_files:
        raise FileNotFoundError("No freeze entry files found in project_freeze_ledger/entries")

    freezes = [load_entry(project_root, entry_file) for entry_file in entry_files]

    seen: set[str] = set()
    for freeze in freezes:
        freeze_id = freeze["freeze_id"]
        if freeze_id in seen:
            raise ValueError(f"Duplicate freeze_id: {freeze_id}")
        seen.add(freeze_id)

    return sorted(freezes, key=lambda item: item["freeze_id"])


def validate_master_consistency(project_root: Path, freezes: List[Dict[str, Any]]) -> None:
    master_path = project_root / MASTER_REL_PATH

    if not master_path.exists():
        raise FileNotFoundError(f"Missing master ledger: {MASTER_REL_PATH.as_posix()}")

    master_text = master_path.read_text(encoding="utf-8")

    if DRIVE_RE.search(master_text):
        raise ValueError("master ledger contains drive-letter absolute path")

    freeze_ids_from_entries = {freeze["freeze_id"] for freeze in freezes}

    for freeze_id in sorted(freeze_ids_from_entries):
        if freeze_id not in master_text:
            raise ValueError(f"Master ledger does not mention freeze entry: {freeze_id}")

    freeze_ids_from_master = set(FREEZE_ID_RE.findall(master_text))
    missing_entries = sorted(freeze_ids_from_master - freeze_ids_from_entries)

    if missing_entries:
        raise ValueError(
            "Master ledger mentions freeze IDs with no matching entry: "
            + ", ".join(missing_entries)
        )


def build_index(project_root: Path, generated_at_utc: str | None = None) -> Dict[str, Any]:
    freezes = load_freezes(project_root)
    validate_master_consistency(project_root, freezes)

    if generated_at_utc is None:
        generated_at_utc = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()

    return {
        "schema_version": SCHEMA_VERSION,
        "generated_at_utc": generated_at_utc,
        "project_root_placeholder": "<project_root>",
        "canonical_source": CANONICAL_SOURCE,
        "generated_by": GENERATOR,
        "entries_count": len(freezes),
        "freezes": freezes,
    }


def normalize_for_compare(index_data: Dict[str, Any]) -> Dict[str, Any]:
    normalized = json.loads(json.dumps(index_data, sort_keys=True))
    normalized["generated_at_utc"] = "<ignored_for_sync_check>"
    return normalized


def write_index(project_root: Path) -> Path:
    index_data = build_index(project_root)
    index_path = project_root / INDEX_REL_PATH
    index_path.write_text(
        json.dumps(index_data, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return index_path


def check_index(project_root: Path) -> Tuple[bool, str]:
    index_path = project_root / INDEX_REL_PATH
    if not index_path.exists():
        return False, "freeze_index.json is missing. Run with --sync."

    try:
        current_index = json.loads(index_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return False, f"freeze_index.json is invalid JSON: {exc}"

    expected_index = build_index(
        project_root,
        generated_at_utc=str(current_index.get("generated_at_utc", "")) or None,
    )

    if normalize_for_compare(current_index) != normalize_for_compare(expected_index):
        return False, "freeze_index.json is out of sync with structured freeze entries."

    return True, "freeze_index.json is in sync with structured freeze entries."


def print_summary(index_data: Dict[str, Any]) -> None:
    print(f"schema_version={index_data['schema_version']}")
    print(f"entries_count={index_data['entries_count']}")
    for freeze in index_data["freezes"]:
        print(
            f"- {freeze['freeze_id']} "
            f"[{freeze['status']}] "
            f"paths={len(freeze['protected_paths'])} "
            f"entry={freeze['entry']}"
        )


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Build/check project_freeze_ledger/freeze_index.json from structured freeze entries."
    )
    parser.add_argument(
        "--project-root",
        default="",
        help="Optional project root. If omitted, auto-detect from current folder.",
    )
    parser.add_argument(
        "--sync",
        action="store_true",
        help="Generate or update project_freeze_ledger/freeze_index.json.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check that project_freeze_ledger/freeze_index.json is valid and in sync.",
    )
    parser.add_argument(
        "--print",
        action="store_true",
        help="Print generated index summary without writing the JSON file.",
    )

    args = parser.parse_args(argv)

    try:
        mode_count = int(args.sync) + int(args.check) + int(args.print)
        if mode_count != 1:
            raise ValueError("Choose exactly one mode: --sync, --check, or --print.")

        if args.project_root:
            project_root = Path(args.project_root).resolve()
        else:
            project_root = find_project_root(Path.cwd())

        if not (project_root / "project_freeze_ledger").is_dir():
            raise FileNotFoundError("Detected project root does not contain project_freeze_ledger.")

        if args.sync:
            index_path = write_index(project_root)
            index_data = json.loads(index_path.read_text(encoding="utf-8"))
            print("SYNC OK")
            print(f"project_root={project_root}")
            print(f"index={index_path}")
            print_summary(index_data)
            print("freeze_index.json is generated from Markdown entries. Do not edit it manually.")
            return 0

        if args.check:
            ok, message = check_index(project_root)
            print("CHECK OK" if ok else "CHECK FAILED")
            print(f"project_root={project_root}")
            print(message)
            if ok:
                index_data = json.loads((project_root / INDEX_REL_PATH).read_text(encoding="utf-8"))
                print_summary(index_data)
                print("No protected path checker was created.")
                return 0
            return 1

        if args.print:
            index_data = build_index(project_root)
            print("PRINT OK")
            print_summary(index_data)
            return 0

        raise AssertionError("unreachable")

    except Exception as exc:
        print("FREEZE INDEX FAILED", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
