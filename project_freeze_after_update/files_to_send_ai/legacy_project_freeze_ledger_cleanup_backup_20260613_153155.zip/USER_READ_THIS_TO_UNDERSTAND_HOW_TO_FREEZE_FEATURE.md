# USER READ THIS TO UNDERSTAND HOW TO FREEZE FEATURE

This file is the human-facing guide for freezing a completed feature in the KANDA / kanda_reasoner project.

## Important dynamic path rule

Do not hardcode a fixed local machine path in project files.

Use a dynamic project root placeholder:

```text
<project_root>
```

The project root is the folder that contains:

```text
project_freeze_ledger/
kanda_prompt_workspace/
```

## What each freeze file is for

```text
project_freeze_ledger/readme_project_freeze_ledger.md
= explains the governance rules

project_freeze_ledger/project_frozen_implemented_steps.md
= master dashboard showing what boxes are frozen

project_freeze_ledger/send_to_ai_when_freezing_feature.md
= reusable AI-facing helper to freeze any feature

project_freeze_ledger/entries/freeze-....md
= detailed law/proof/protected paths for each frozen box
```

## What to send to AI when freezing a feature

Always send:

```text
project_freeze_ledger/readme_project_freeze_ledger.md
project_freeze_ledger/project_frozen_implemented_steps.md
project_freeze_ledger/send_to_ai_when_freezing_feature.md
```

If the feature touches a frozen area, also send the relevant entry from:

```text
project_freeze_ledger/entries/
```

If you are not sure which frozen area is relevant, send all entries.

## How AI knows what is frozen

AI must read:

```text
project_freeze_ledger/project_frozen_implemented_steps.md
```

Then AI must read the relevant detailed entry from:

```text
project_freeze_ledger/entries/
```

Each entry now starts with structured frontmatter. The most important field is:

```text
protected_paths
```

That field lists which project-root-relative files and folders are protected.

## Human rule

When in doubt, ask AI:

```text
This task touches protected path? yes/no

If yes, which freeze entry must be read before proceeding?
If uncertain, read all entries.
```

## What not to do

Do not:

```text
freeze incomplete work
invent validation
edit frozen files casually
create a manual JSON mirror
use hardcoded local absolute paths
reuse old broken install scripts
```

## Validator

After structured freeze entry changes, run:

```text
project_freeze_ledger/freeze_tools/validate_freeze_entry_frontmatter.py
```

This checks the structured entry metadata before future automation is built.
