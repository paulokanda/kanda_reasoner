# USER READ THIS TO UNDERSTAND HOW TO FREEZE FEATURE

This file explains how to freeze a completed feature in the KANDA / kanda_reasoner project.

## Important dynamic path rule

Do not hardcode a fixed Windows path such as:

```text
E:\kanda_reasoner\...
```

The project may later be compiled, moved, renamed, zipped, restored, or installed somewhere else.

Use a dynamic project root placeholder:

```text
<project_root>
```

In your current development machine, `<project_root>` may be `E:\kanda_reasoner`, but future installs may use another path.

## How to find the project root

The project root is the folder that contains:

```text
project_freeze_ledger/
kanda_prompt_workspace/
```

If you are inside `kanda_prompt_workspace`, the freeze ledger is not inside that folder. It is one level above, at the project root.

## Main freeze ledger files

Use these dynamic paths:

```text
<project_root>/project_freeze_ledger/readme_project_freeze_ledger.md
<project_root>/project_freeze_ledger/project_frozen_implemented_steps.md
<project_root>/project_freeze_ledger/send_to_ai_when_freezing_feature.md
<project_root>/project_freeze_ledger/entries/
```

## How to check if they exist

From the project root, run:

```powershell
Test-Path ".\project_freeze_ledger\readme_project_freeze_ledger.md"
Test-Path ".\project_freeze_ledger\project_frozen_implemented_steps.md"
Test-Path ".\project_freeze_ledger\send_to_ai_when_freezing_feature.md"
Test-Path ".\project_freeze_ledger\entries"
```

All should return `True`.

## Practical daily workflow

When a feature is finished and validated:

```text
1. Open <project_root>/project_freeze_ledger/send_to_ai_when_freezing_feature.md
2. Send AI the files listed there
3. Paste the validation evidence
4. Ask AI to freeze the implemented box
5. AI should return a ZIP patch
6. Install the ZIP patch from the project root
7. Validate the freeze ledger
```

## Files to send to AI when freezing

Always send/read:

```text
<project_root>/project_freeze_ledger/readme_project_freeze_ledger.md
<project_root>/project_freeze_ledger/project_frozen_implemented_steps.md
<project_root>/project_freeze_ledger/send_to_ai_when_freezing_feature.md
```

If the feature touches an already frozen box, also send/read the relevant entry from:

```text
<project_root>/project_freeze_ledger/entries/
```

Example:

```text
<project_root>/project_freeze_ledger/entries/freeze-20260612-phase7a-v24.md
```

## Copy this prompt to AI

```text
Freeze this implemented box.

Read these freeze ledger files first:
- <project_root>/project_freeze_ledger/readme_project_freeze_ledger.md
- <project_root>/project_freeze_ledger/project_frozen_implemented_steps.md
- <project_root>/project_freeze_ledger/send_to_ai_when_freezing_feature.md

If I provide an existing freeze entry from <project_root>/project_freeze_ledger/entries/, use it as boundary context.

Box name:
[paste box name]

Frozen version:
[paste version or baseline]

What was implemented:
[paste short summary]

Validation evidence:
[paste terminal validation output]

Behavioral tests:
[paste behavior tests if relevant]

User acceptance:
[paste acceptance, for example: user approved after validation]

Do-not-touch boundaries:
[paste known boundaries, or ask AI to infer and propose them]

Task:
1. Decide whether this is freeze-worthy.
2. If freeze-worthy, create one new detailed freeze entry in project_freeze_ledger/entries/.
3. Update project_freeze_ledger/project_frozen_implemented_steps.md.
4. Update project_freeze_ledger/readme_project_freeze_ledger.md only if the freeze protocol itself changed or this human guide needs a reference update.
5. Do not modify project logic.
6. Do not create a JSON mirror yet.
7. Do not invent validation.
8. Return a ZIP patch containing only the needed project_freeze_ledger files and install/validate scripts.
```

## Minimum evidence to paste

At minimum, paste:

```text
implementation summary
validation output
user acceptance
next allowed step
```

If available, also paste:

```text
behavioral tests
file listing
before/after comparison
external review
```

## What AI should update

For most freezes, AI should update only:

```text
project_freeze_ledger/project_frozen_implemented_steps.md
project_freeze_ledger/entries/freeze-yyyymmdd-box-name-version.md
```

AI should update this guide only when the freeze process itself changed or a human workflow reference must be added.

## What AI should not do

During a freeze-only task, AI should not:

```text
change source code
change prompt logic
change architecture
modify generated artifacts as source
invent validation
freeze incomplete work
create a JSON mirror manually
create duplicate freeze IDs
hardcode local absolute paths
```

## Freeze ID format

Use lower-case freeze IDs:

```text
freeze-yyyymmdd-box-name-version
```

Examples:

```text
freeze-20260612-phase7a-v24
freeze-20260612-project-freeze-ledger-v1
freeze-20260613-send-to-ai-if-requested-v1
```

## Required sections in every freeze entry

Every detailed freeze entry should include:

```text
## freeze identity
## frozen version
## summary
## what was implemented
## files and folders affected
## validation evidence summary
## behavioral tests
## what is explicitly not included
## do-not-touch boundaries
## downstream dependencies
## exposure classification
## external AI sharing rule
## rollback / break-glass protocol
## next allowed step
```

## Quick command

When in doubt, say:

```text
Freeze this implemented box using project_freeze_ledger. Update the master Markdown and create one detailed entry. Return a ZIP patch. Do not modify project logic. Use dynamic <project_root> paths only.
```

## Important note about filename case

This file intentionally uses the uppercase `USER_READ_THIS...` style because it is a human-facing guide.

Other operational freeze ledger files should stay lower case unless the user explicitly asks otherwise.
