#!/usr/bin/env python3
"""
files_needed_for_freezing.py

Creates the current AI-send pack for freezing a feature.

Scope:
- Works inside <project_root>/project_freeze_ledger.
- Outputs generated files inside:
  project_freeze_ledger/ai_send_files_to_freeze_feature/
- Before creating a new pack, deletes older generated AI-send files from that folder.
- Uses dynamic project-root detection.
- Includes current freeze context:
  structured entries, freeze_index.json, freeze index builder, protected path checker.
- Validation scripts are not required in the AI-send pack; validation evidence should be pasted as terminal output.
- Does not create freeze entries.
- Does not freeze any feature by itself.
- Uses Python standard library only.
"""

from __future__ import annotations

import datetime as _dt
import importlib.util
import json
import sys
import zipfile
from pathlib import Path
from types import ModuleType
from typing import Iterable, List, Tuple


OUTPUT_DIR_REL = Path("project_freeze_ledger/ai_send_files_to_freeze_feature")
WHAT_TO_SAY_REL = OUTPUT_DIR_REL / "what_to_say_to_ai_freeze_feature.md"
PACK_PATTERN = "freeze_feature_ai_send_pack_*.zip"

REQUIRED_BASE_FILES = [
    Path("project_freeze_ledger/freeze_index.json"),
    Path("project_freeze_ledger/project_frozen_implemented_steps.md"),
    Path("project_freeze_ledger/readme_project_freeze_ledger.md"),
    Path("project_freeze_ledger/send_to_ai_when_freezing_feature.md"),
]

OPTIONAL_BASE_FILES = [
    Path("project_freeze_ledger/USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md"),
]

REQUIRED_TOOL_FILES = [
    Path("project_freeze_ledger/freeze_tools/build_freeze_index.py"),
    Path("project_freeze_ledger/freeze_tools/check_protected_paths.py"),
    Path("project_freeze_ledger/freeze_tools/files_needed_for_freezing.py"),
]

OPTIONAL_RECOVERY_FILES = [
    Path("project_freeze_ledger/freeze_tools/repair_v19_structured_entries.py"),
]

# Validation scripts are intentionally not included as required files anymore.
# User should paste validation terminal output when asking an AI to freeze a feature.


def find_project_root(start: Path) -> Path:
    current = start.resolve()
    if current.is_file():
        current = current.parent

    while True:
        if (current / "project_freeze_ledger").is_dir():
            return current
        if current.parent == current:
            raise FileNotFoundError("Could not find project_freeze_ledger from current path.")
        current = current.parent


def load_module(path: Path, module_name: str) -> ModuleType:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def ensure_freeze_index_synced(project_root: Path) -> None:
    builder_path = project_root / "project_freeze_ledger" / "freeze_tools" / "build_freeze_index.py"

    if not builder_path.exists():
        raise FileNotFoundError(
            "Missing project_freeze_ledger/freeze_tools/build_freeze_index.py. "
            "Cannot generate current AI-send pack safely."
        )

    builder = load_module(builder_path, "build_freeze_index_for_ai_send_pack")

    if not hasattr(builder, "write_index") or not hasattr(builder, "check_index"):
        raise RuntimeError("build_freeze_index.py does not expose expected write_index/check_index functions.")

    builder.write_index(project_root)
    ok, message = builder.check_index(project_root)

    if not ok:
        raise RuntimeError(message)


def cleanup_generated_ai_send_files(project_root: Path) -> List[Path]:
    output_dir = project_root / OUTPUT_DIR_REL
    output_dir.mkdir(parents=True, exist_ok=True)

    deleted: List[Path] = []

    for old_zip in sorted(output_dir.glob(PACK_PATTERN)):
        if old_zip.is_file():
            old_zip.unlink()
            deleted.append(old_zip.relative_to(project_root))

    what_to_say = project_root / WHAT_TO_SAY_REL
    if what_to_say.exists() and what_to_say.is_file():
        what_to_say.unlink()
        deleted.append(what_to_say.relative_to(project_root))

    return deleted


def require_existing(project_root: Path, rel_paths: Iterable[Path]) -> List[Path]:
    existing: List[Path] = []

    for rel_path in rel_paths:
        full_path = project_root / rel_path
        if not full_path.exists():
            raise FileNotFoundError(f"Missing required file: {rel_path.as_posix()}")
        existing.append(rel_path)

    return existing


def include_optional(project_root: Path, rel_paths: Iterable[Path]) -> List[Path]:
    existing: List[Path] = []

    for rel_path in rel_paths:
        if (project_root / rel_path).exists():
            existing.append(rel_path)

    return existing


def collect_entry_files(project_root: Path) -> List[Path]:
    entries_dir = project_root / "project_freeze_ledger" / "entries"

    if not entries_dir.is_dir():
        raise FileNotFoundError("Missing project_freeze_ledger/entries folder")

    entries = sorted(Path("project_freeze_ledger/entries") / item.name for item in entries_dir.glob("*.md"))

    if not entries:
        raise FileNotFoundError("No freeze entries found in project_freeze_ledger/entries")

    return entries


def load_freeze_index(project_root: Path) -> dict:
    index_path = project_root / "project_freeze_ledger" / "freeze_index.json"
    data = json.loads(index_path.read_text(encoding="utf-8"))

    if data.get("schema_version") != "1.0":
        raise ValueError("freeze_index.json schema_version must be 1.0")

    freezes = data.get("freezes")
    if not isinstance(freezes, list) or not freezes:
        raise ValueError("freeze_index.json must contain a non-empty freezes list")

    return data


def render_what_to_say(project_root: Path, zip_rel: Path, included_files: List[Path], deleted_files: List[Path]) -> str:
    index = load_freeze_index(project_root)
    freeze_ids = [str(item.get("freeze_id")) for item in index.get("freezes", []) if isinstance(item, dict)]

    included_lines = "\n".join(f"- {path.as_posix()}" for path in included_files)
    freeze_lines = "\n".join(f"- {freeze_id}" for freeze_id in freeze_ids)

    if deleted_files:
        deleted_lines = "\n".join(f"- {path.as_posix()}" for path in deleted_files)
    else:
        deleted_lines = "- none"

    return f"""# What to say to AI when freezing a feature

This file was generated by:

```text
project_freeze_ledger/freeze_tools/files_needed_for_freezing.py
```

AI-send ZIP generated:

```text
{zip_rel.as_posix()}
```

Generated-file cleanup before this pack:

```text
Older generated files removed from project_freeze_ledger/ai_send_files_to_freeze_feature before creating this pack.
```

Deleted generated files:

```text
{deleted_lines}
```

## Message to paste into the AI chat

I am asking you to freeze a validated feature in the KANDA project.

Use the attached AI-send ZIP as the current freeze-ledger context.

Important rules:

```text
1. Work only with project-root-relative paths.
2. Treat <project_root> as dynamic; do not hardcode local absolute paths.
3. Markdown freeze entries are canonical.
4. freeze_index.json is a generated fast index, not the authority.
5. Before modifying or freezing a protected path, use/check the protected path result and read the detailed freeze entry.
6. If a path is PROTECTED: yes, read every listed Entry file before proposing changes.
7. Do not rely only on freeze_index.json.
8. Do not create root-level helper scripts for project_freeze_ledger-only tasks.
9. Keep new changes as small closed boxes.
10. Do not freeze until validation evidence is provided.
11. Validation scripts may not be present in the AI-send ZIP; rely on the pasted terminal validation log as evidence.
```

Before freezing, I will provide:

```text
1. validation log proving the feature passed
2. list of files changed by the feature
3. patch ZIP or changed files
4. brief explanation of what the feature does
```

If the feature touches specific paths, check them with:

```text
project_freeze_ledger/freeze_tools/check_protected_paths.py --paths <changed paths>
```

If the checker reports `PROTECTED: yes`, read the listed detailed entry files under:

```text
project_freeze_ledger/entries/
```

## Current freeze IDs in freeze_index.json

{freeze_lines}

## Files included in this AI-send ZIP

{included_lines}

## Reminder

The AI-send ZIP is context for the AI.

It does not by itself freeze a feature.

The freeze patch should create or update the appropriate freeze entry only after validation evidence is reviewed.
"""


def build_ai_send_pack(project_root: Path) -> Tuple[Path, Path, List[Path], List[Path]]:
    ensure_freeze_index_synced(project_root)

    output_dir = project_root / OUTPUT_DIR_REL
    output_dir.mkdir(parents=True, exist_ok=True)

    deleted_files = cleanup_generated_ai_send_files(project_root)

    timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_rel = OUTPUT_DIR_REL / f"freeze_feature_ai_send_pack_{timestamp}.zip"
    zip_path = project_root / zip_rel

    included_files: List[Path] = []
    included_files.extend(require_existing(project_root, REQUIRED_BASE_FILES))
    included_files.extend(include_optional(project_root, OPTIONAL_BASE_FILES))
    included_files.extend(collect_entry_files(project_root))
    included_files.extend(require_existing(project_root, REQUIRED_TOOL_FILES))
    included_files.extend(include_optional(project_root, OPTIONAL_RECOVERY_FILES))

    deduped: List[Path] = []
    seen: set[str] = set()
    for rel_path in included_files:
        key = rel_path.as_posix()
        if key not in seen:
            seen.add(key)
            deduped.append(rel_path)

    what_to_say_text = render_what_to_say(project_root, zip_rel, deduped, deleted_files)
    what_to_say_path = project_root / WHAT_TO_SAY_REL
    what_to_say_path.write_text(what_to_say_text, encoding="utf-8", newline="\n")

    if WHAT_TO_SAY_REL.as_posix() not in seen:
        deduped.append(WHAT_TO_SAY_REL)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for rel_path in deduped:
            full_path = project_root / rel_path
            if not full_path.exists():
                raise FileNotFoundError(f"Cannot add missing file to ZIP: {rel_path.as_posix()}")
            archive.write(full_path, rel_path.as_posix())

    return zip_path, what_to_say_path, deduped, deleted_files


def main() -> int:
    try:
        project_root = find_project_root(Path.cwd())
        zip_path, what_to_say_path, included_files, deleted_files = build_ai_send_pack(project_root)

        print("AI-SEND PACK OK")
        print(f"project_root={project_root}")
        print(f"zip={zip_path}")
        print(f"what_to_say={what_to_say_path}")
        print(f"deleted_generated_files={len(deleted_files)}")
        for rel_path in deleted_files:
            print(f"DELETED {rel_path.as_posix()}")
        print(f"files_included={len(included_files)}")

        for rel_path in included_files:
            print(f"- {rel_path.as_posix()}")

        print("")
        print("Send the ZIP and paste the text from what_to_say_to_ai_freeze_feature.md into the AI chat.")
        return 0

    except Exception as exc:
        print("AI-SEND PACK FAILED", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
