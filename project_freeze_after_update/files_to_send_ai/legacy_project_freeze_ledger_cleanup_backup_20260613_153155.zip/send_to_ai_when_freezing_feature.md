# send to ai when freezing feature

Use this file when a feature, module, prompt box, script, workflow, UI box, delivery system, or project baseline is finished and you want AI to freeze it correctly.

This is the practical AI-facing helper.

## what to send to ai

Always send these base files first:

```text
project_freeze_ledger/readme_project_freeze_ledger.md
project_freeze_ledger/project_frozen_implemented_steps.md
project_freeze_ledger/send_to_ai_when_freezing_feature.md
```

Then decide whether entries are needed:

```text
If the feature touches a protected path, send the relevant entry from project_freeze_ledger/entries/.
If relevance is unclear, send all entries from project_freeze_ledger/entries/.
```

The structured frontmatter in each entry contains the `protected_paths` list.

## copy and paste this prompt to ai

```text
Freeze this implemented box.

Read these freeze ledger files first:
- project_freeze_ledger/readme_project_freeze_ledger.md
- project_freeze_ledger/project_frozen_implemented_steps.md
- project_freeze_ledger/send_to_ai_when_freezing_feature.md

Before creating or updating any freeze entry, answer this checkpoint:

This task touches protected path? yes/no

Rules:
- If no, proceed using the base freeze protocol.
- If yes, read the relevant detailed freeze entry from project_freeze_ledger/entries/ before proposing changes.
- If uncertain which frozen box is relevant, read all entries in project_freeze_ledger/entries/.
- To know exact protected boundaries, inspect protected_paths in the entry frontmatter and then read the full entry body.
- If the relevant detailed entry is missing, stop and ask me for the missing entry file.
- Do not modify frozen files casually.
- Do not reintroduce hardcoded local absolute paths.
- Use <project_root> or project-root-relative paths.
- Do not create a JSON mirror unless explicitly requested.
- Do not invent validation.

Box name:
[paste box name]

Frozen version:
[paste version or baseline]

What was implemented:
[paste short summary]

Validation evidence:
[paste terminal validation output]

Behavioral tests:
[paste behavior tests if relevant]

User acceptance:
[paste acceptance, for example: user approved after validation]

Do-not-touch boundaries:
[paste known boundaries, or infer and propose them]

Task:
1. Decide whether this is freeze-worthy.
2. Identify whether this task touches protected paths.
3. If it touches protected paths, read the relevant entry or all entries if uncertain.
4. If freeze-worthy, create one new detailed freeze entry in project_freeze_ledger/entries/.
5. The new entry must start with structured frontmatter.
6. Update project_freeze_ledger/project_frozen_implemented_steps.md.
7. Update project_freeze_ledger/readme_project_freeze_ledger.md only if the freeze protocol itself changed.
8. Do not modify project logic.
9. Do not create a JSON mirror yet.
10. Do not invent validation.
11. Return a ZIP patch that contains only the needed project_freeze_ledger files and install/validate scripts.
```

## frontmatter requirement for new entries

Every new freeze entry must begin with:

```text
---
schema_version: 1.0
freeze_id: freeze-yyyymmdd-box-version
box: box_name
status: frozen
date: yyyy-mm-dd
freeze_tier: tier1-governance-baseline OR tier2-operational-implementation
entry: project_freeze_ledger/entries/freeze-yyyymmdd-box-version.md
protected_paths:
  - relative/path/or/folder/
do_not_touch_summary:
  - summary item
superseded_by:
---
```

Do not use hardcoded local absolute paths in frontmatter.
