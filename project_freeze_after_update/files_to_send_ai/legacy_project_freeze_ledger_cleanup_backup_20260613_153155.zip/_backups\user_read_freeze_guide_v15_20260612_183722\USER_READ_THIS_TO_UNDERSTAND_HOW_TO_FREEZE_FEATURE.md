# USER READ THIS TO UNDERSTAND HOW TO FREEZE FEATURE

This file is the practical human guide for freezing a completed feature in the KANDA / kanda_reasoner project.

## Important location rule

The freeze ledger is at the project root:

```text
E:\kanda_reasoner\project_freeze_ledger
```

It is intentionally **not** inside:

```text
E:\kanda_reasoner\kanda_prompt_workspace
```

So if you are standing in PowerShell at:

```text
E:\kanda_reasoner\kanda_prompt_workspace
```

the relative path below will not work:

```text
project_freeze_ledger\...
```

Use the absolute paths shown in this guide.

## What freeze means

A freeze means:

```text
This feature or project box was implemented, validated, accepted, and should not be casually changed later.
```

A freeze is not just a note. It becomes part of the project memory.

## Main freeze ledger files

These files should exist:

```text
E:\kanda_reasoner\project_freeze_ledger\readme_project_freeze_ledger.md
E:\kanda_reasoner\project_freeze_ledger\project_frozen_implemented_steps.md
E:\kanda_reasoner\project_freeze_ledger\send_to_ai_when_freezing_feature.md
E:\kanda_reasoner\project_freeze_ledger\entries\
```

## How to check if they exist

Run:

```powershell
Test-Path "E:\kanda_reasoner\project_freeze_ledger\readme_project_freeze_ledger.md"
Test-Path "E:\kanda_reasoner\project_freeze_ledger\project_frozen_implemented_steps.md"
Test-Path "E:\kanda_reasoner\project_freeze_ledger\send_to_ai_when_freezing_feature.md"
Test-Path "E:\kanda_reasoner\project_freeze_ledger\entries"
```

All should return:

```text
True
```

## Practical daily workflow

When a feature is finished and validated:

```text
1. Open E:\kanda_reasoner\project_freeze_ledger\send_to_ai_when_freezing_feature.md
2. Send AI the files listed there
3. Paste the validation evidence
4. Ask AI to freeze the implemented box
5. AI should return a ZIP patch
6. Install the ZIP patch
7. Validate the freeze ledger
```

## Files to send to AI when freezing

Always send/read these absolute paths:

```text
E:\kanda_reasoner\project_freeze_ledger\readme_project_freeze_ledger.md
E:\kanda_reasoner\project_freeze_ledger\project_frozen_implemented_steps.md
E:\kanda_reasoner\project_freeze_ledger\send_to_ai_when_freezing_feature.md
```

If the feature touches an already frozen box, also send/read the relevant entry from:

```text
E:\kanda_reasoner\project_freeze_ledger\entries\
```

Example:

```text
E:\kanda_reasoner\project_freeze_ledger\entries\freeze-20260612-phase7a-v24.md
```

## Copy this prompt to AI

```text
Freeze this implemented box.

Read these freeze ledger files first:
- E:\kanda_reasoner\project_freeze_ledger\readme_project_freeze_ledger.md
- E:\kanda_reasoner\project_freeze_ledger\project_frozen_implemented_steps.md
- E:\kanda_reasoner\project_freeze_ledger\send_to_ai_when_freezing_feature.md

If I provide an existing freeze entry from E:\kanda_reasoner\project_freeze_ledger\entries\, use it as boundary context.

Box name:
[paste box name]

Frozen version:
[paste version or baseline]

What was implemented:
[paste short summary]

Validation evidence:
[paste terminal validation output]

Behavioral tests:
[paste behavior tests if relevant]

User acceptance:
[paste acceptance, for example: user approved after validation]

Do-not-touch boundaries:
[paste known boundaries, or ask AI to infer and propose them]

Task:
1. Decide whether this is freeze-worthy.
2. If freeze-worthy, create one new detailed freeze entry in project_freeze_ledger/entries/.
3. Update project_freeze_ledger/project_frozen_implemented_steps.md.
4. Update project_freeze_ledger/readme_project_freeze_ledger.md only if the freeze protocol itself changed or this human guide needs a reference update.
5. Do not modify project logic.
6. Do not create a JSON mirror yet.
7. Do not invent validation.
8. Return a ZIP patch containing only the needed project_freeze_ledger files and install/validate scripts.
```

## Minimum evidence to paste

At minimum, paste:

```text
implementation summary
validation output
user acceptance
next allowed step
```

If available, also paste:

```text
behavioral tests
file listing
before/after comparison
external review
```

## What AI should update

For most freezes, AI should update only:

```text
project_freeze_ledger/project_frozen_implemented_steps.md
project_freeze_ledger/entries/freeze-yyyymmdd-box-name-version.md
```

AI should update this guide only when the freeze process itself changed or a human workflow reference must be added.

## What AI should not do

During a freeze-only task, AI should not:

```text
change source code
change prompt logic
change architecture
modify generated artifacts as source
invent validation
freeze incomplete work
create a JSON mirror manually
create duplicate freeze IDs
```

## Freeze ID format

Use lower-case freeze IDs:

```text
freeze-yyyymmdd-box-name-version
```

Examples:

```text
freeze-20260612-phase7a-v24
freeze-20260612-project-freeze-ledger-v1
freeze-20260613-send-to-ai-if-requested-v1
```

## Required sections in every freeze entry

Every detailed freeze entry should include:

```text
## freeze identity
## frozen version
## summary
## what was implemented
## files and folders affected
## validation evidence summary
## behavioral tests
## what is explicitly not included
## do-not-touch boundaries
## downstream dependencies
## exposure classification
## external AI sharing rule
## rollback / break-glass protocol
## next allowed step
```

## Quick command

When in doubt, say:

```text
Freeze this implemented box using project_freeze_ledger. Update the master Markdown and create one detailed entry. Return a ZIP patch. Do not modify project logic.
```

## Important note about filename case

This file intentionally uses the uppercase `USER_READ_THIS...` style because it is a human-facing guide.

Other operational freeze ledger files should stay lower case unless the user explicitly asks otherwise.
