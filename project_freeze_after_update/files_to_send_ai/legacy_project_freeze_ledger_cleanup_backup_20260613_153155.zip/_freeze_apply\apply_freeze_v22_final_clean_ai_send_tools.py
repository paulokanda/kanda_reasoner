#!/usr/bin/env python3
"""
apply_freeze_v22_final_clean_ai_send_tools.py

One-time freeze apply/check script for:
freeze-20260612-project-freeze-ledger-v22-final-clean-ai-send-tools

This script:
- verifies the final clean freeze_tools folder
- records the freeze in the master ledger
- syncs freeze_index.json
- verifies protected-path matching
- regenerates and inspects the AI-send pack
- does not create permanent files in freeze_tools
"""

from __future__ import annotations

import datetime as _dt
import json
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Iterable


FREEZE_ID = "freeze-20260612-project-freeze-ledger-v22-final-clean-ai-send-tools"
ENTRY_REL = Path(f"project_freeze_ledger/entries/{FREEZE_ID}.md")
TOOLS_REL = Path("project_freeze_ledger/freeze_tools")
MASTER_REL = Path("project_freeze_ledger/project_frozen_implemented_steps.md")
INDEX_REL = Path("project_freeze_ledger/freeze_index.json")
AI_SEND_REL = Path("project_freeze_ledger/ai_send_files_to_freeze_feature")

PERMANENT_TOOL_NAMES = {
    "build_freeze_index.py",
    "check_protected_paths.py",
    "files_needed_for_freezing.py",
}

FORBIDDEN_TOOL_NAMES = {
    "cleanup_validators_after_validation.py",
    "repair_v19_structured_entries.py",
}

REQUIRED_PACK_ITEMS = {
    "project_freeze_ledger/freeze_index.json",
    "project_freeze_ledger/project_frozen_implemented_steps.md",
    "project_freeze_ledger/readme_project_freeze_ledger.md",
    "project_freeze_ledger/send_to_ai_when_freezing_feature.md",
    "project_freeze_ledger/freeze_tools/build_freeze_index.py",
    "project_freeze_ledger/freeze_tools/check_protected_paths.py",
    "project_freeze_ledger/freeze_tools/files_needed_for_freezing.py",
    f"project_freeze_ledger/entries/{FREEZE_ID}.md",
    "project_freeze_ledger/ai_send_files_to_freeze_feature/what_to_say_to_ai_freeze_feature.md",
}


def find_project_root(start: Path) -> Path:
    current = start.resolve()
    if current.is_file():
        current = current.parent

    while True:
        if (current / "project_freeze_ledger").is_dir():
            return current
        if current.parent == current:
            raise FileNotFoundError("Could not find project_freeze_ledger from current path.")
        current = current.parent


def run_py(project_root: Path, rel_script: Path, args: list[str] | None = None, timeout: int = 120) -> subprocess.CompletedProcess[str]:
    if args is None:
        args = []

    script = project_root / rel_script
    if not script.exists():
        raise FileNotFoundError(f"Missing script: {rel_script.as_posix()}")

    result = subprocess.run(
        [sys.executable, str(script), *args],
        cwd=str(project_root),
        capture_output=True,
        text=True,
        timeout=timeout,
    )

    print("")
    print(f"--- {rel_script.as_posix()} {' '.join(args)} ---")
    print(f"returncode={result.returncode}")

    if result.stdout:
        print(result.stdout)

    if result.stderr:
        print("STDERR:")
        print(result.stderr)

    return result


def ensure_exists(project_root: Path, rel_paths: Iterable[Path]) -> None:
    for rel in rel_paths:
        if not (project_root / rel).exists():
            raise FileNotFoundError(f"Missing required path: {rel.as_posix()}")


def verify_clean_freeze_tools(project_root: Path) -> None:
    tools_dir = project_root / TOOLS_REL
    if not tools_dir.is_dir():
        raise FileNotFoundError("Missing project_freeze_ledger/freeze_tools")

    py_files = sorted(item.name for item in tools_dir.glob("*.py"))
    unexpected = sorted(name for name in py_files if name not in PERMANENT_TOOL_NAMES)

    if unexpected:
        raise RuntimeError(
            "freeze_tools is not clean. Unexpected .py files remain: "
            + ", ".join(unexpected)
            + ". Delete them or move them outside freeze_tools before freezing."
        )

    missing = sorted(name for name in PERMANENT_TOOL_NAMES if not (tools_dir / name).exists())
    if missing:
        raise RuntimeError("freeze_tools missing permanent tools: " + ", ".join(missing))

    for name in FORBIDDEN_TOOL_NAMES:
        if (tools_dir / name).exists():
            raise RuntimeError(f"Forbidden maintenance tool still exists in freeze_tools: {name}")

    validate_files = sorted(item.name for item in tools_dir.glob("validate_*.py"))
    if validate_files:
        raise RuntimeError("validate_*.py files still remain: " + ", ".join(validate_files))

    print("OK clean freeze_tools contains only permanent tools:")
    for name in sorted(PERMANENT_TOOL_NAMES):
        print(f"- {TOOLS_REL.as_posix()}/{name}")


def append_master_section(project_root: Path) -> None:
    master = project_root / MASTER_REL
    text = master.read_text(encoding="utf-8")

    if FREEZE_ID in text:
        print("OK master ledger already contains final clean freeze id.")
        return

    backup_dir = project_root / "project_freeze_ledger" / "_backups" / f"apply_{FREEZE_ID}_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    backup_dir.mkdir(parents=True, exist_ok=True)
    (backup_dir / MASTER_REL.name).write_text(text, encoding="utf-8", newline="\n")

    section = f"""

## {FREEZE_ID}

```text
status: frozen
date: 2026-06-12
box: project_freeze_ledger/final_clean_ai_send_tools
entry: project_freeze_ledger/entries/{FREEZE_ID}.md
```

Frozen final clean state:

```text
project_freeze_ledger/freeze_tools/build_freeze_index.py
project_freeze_ledger/freeze_tools/check_protected_paths.py
project_freeze_ledger/freeze_tools/files_needed_for_freezing.py
```

Permanent rule:

```text
freeze_tools should not keep validate_*.py, cleanup_validators_after_validation.py, repair_v19_structured_entries.py, or apply_freeze_*.py as permanent files.
```

Generated AI-send packs are convenience outputs. The canonical history remains in `entries/*.md` and this master ledger.
"""

    master.write_text(text.rstrip() + section + "\n", encoding="utf-8", newline="\n")
    print("OK master ledger updated.")
    print(f"Backup created: {backup_dir.relative_to(project_root).as_posix()}")


def inspect_freeze_index(project_root: Path) -> None:
    data = json.loads((project_root / INDEX_REL).read_text(encoding="utf-8"))

    freezes = data.get("freezes")
    if not isinstance(freezes, list):
        raise RuntimeError("freeze_index.json has no freezes list")

    found = [item for item in freezes if isinstance(item, dict) and item.get("freeze_id") == FREEZE_ID]
    if not found:
        raise RuntimeError(f"freeze_index.json missing {FREEZE_ID}")

    entry = found[0]
    if entry.get("status") != "frozen":
        raise RuntimeError(f"{FREEZE_ID} is not frozen in freeze_index.json")

    protected = entry.get("protected_paths")
    if not isinstance(protected, list) or "project_freeze_ledger/freeze_tools/" not in protected:
        raise RuntimeError("Final clean freeze entry must protect project_freeze_ledger/freeze_tools/")

    print("OK freeze_index.json contains final clean freeze.")


def inspect_current_ai_send_pack(project_root: Path) -> None:
    output_dir = project_root / AI_SEND_REL
    packs = sorted(output_dir.glob("freeze_feature_ai_send_pack_*.zip"))

    if len(packs) != 1:
        raise RuntimeError(f"Expected exactly one generated AI-send ZIP, found {len(packs)}")

    pack = packs[0]
    print("")
    print("Inspecting current AI-send pack:")
    print(pack)

    with zipfile.ZipFile(pack, "r") as archive:
        names = set(archive.namelist())

        for required in sorted(REQUIRED_PACK_ITEMS):
            if required not in names:
                raise RuntimeError(f"AI-send pack missing required item: {required}")
            print(f"OK zip item {required}")

        forbidden = sorted(
            name for name in names
            if name.startswith("project_freeze_ledger/freeze_tools/")
            and (
                name.endswith("/validate_")
                or "/validate_" in name
                or name.endswith("cleanup_validators_after_validation.py")
                or name.endswith("repair_v19_structured_entries.py")
                or "/apply_freeze_" in name
            )
        )

        if forbidden:
            raise RuntimeError("AI-send pack contains forbidden maintenance files: " + ", ".join(forbidden))

        tool_items = sorted(
            name for name in names
            if name.startswith("project_freeze_ledger/freeze_tools/")
            and name.endswith(".py")
        )

        expected_tools = sorted(f"project_freeze_ledger/freeze_tools/{name}" for name in PERMANENT_TOOL_NAMES)
        if tool_items != expected_tools:
            raise RuntimeError(
                "AI-send pack freeze_tools items are not exactly the permanent tools. "
                f"Found: {tool_items}. Expected: {expected_tools}"
            )

        entry_items = sorted(
            name for name in names
            if name.startswith("project_freeze_ledger/entries/")
            and name.endswith(".md")
        )
        if f"project_freeze_ledger/entries/{FREEZE_ID}.md" not in entry_items:
            raise RuntimeError("AI-send pack missing final clean freeze entry")

        print(f"OK freeze entries included: {len(entry_items)}")

    what_to_say = output_dir / "what_to_say_to_ai_freeze_feature.md"
    if not what_to_say.exists():
        raise RuntimeError("Missing generated what_to_say_to_ai_freeze_feature.md")

    text = what_to_say.read_text(encoding="utf-8")
    for phrase in [
        "Validation scripts may not be present in the AI-send ZIP",
        "Markdown freeze entries are canonical.",
        "Do not rely only on freeze_index.json.",
    ]:
        if phrase not in text:
            raise RuntimeError(f"what_to_say file missing phrase: {phrase}")
        print(f"OK prompt phrase {phrase}")


def main() -> int:
    try:
        project_root = find_project_root(Path.cwd())

        print("PROJECT_ROOT", project_root)

        ensure_exists(
            project_root,
            [
                ENTRY_REL,
                MASTER_REL,
                INDEX_REL,
                Path("project_freeze_ledger/readme_project_freeze_ledger.md"),
                Path("project_freeze_ledger/send_to_ai_when_freezing_feature.md"),
                Path("project_freeze_ledger/freeze_tools/build_freeze_index.py"),
                Path("project_freeze_ledger/freeze_tools/check_protected_paths.py"),
                Path("project_freeze_ledger/freeze_tools/files_needed_for_freezing.py"),
            ],
        )

        print("")
        print("STEP 1 - Verify clean permanent freeze_tools state")
        verify_clean_freeze_tools(project_root)

        print("")
        print("STEP 2 - Record freeze in master ledger")
        append_master_section(project_root)

        print("")
        print("STEP 3 - Sync and check freeze_index.json")
        result = run_py(project_root, Path("project_freeze_ledger/freeze_tools/build_freeze_index.py"), ["--sync"])
        if result.returncode != 0:
            raise RuntimeError("build_freeze_index.py --sync failed")

        result = run_py(project_root, Path("project_freeze_ledger/freeze_tools/build_freeze_index.py"), ["--check"])
        if result.returncode != 0:
            raise RuntimeError("build_freeze_index.py --check failed")

        inspect_freeze_index(project_root)

        print("")
        print("STEP 4 - Verify protected-path checker sees final clean boundary")
        result = run_py(
            project_root,
            Path("project_freeze_ledger/freeze_tools/check_protected_paths.py"),
            ["--paths", "project_freeze_ledger/freeze_tools/files_needed_for_freezing.py"],
        )
        if result.returncode != 0:
            raise RuntimeError("check_protected_paths.py failed")

        if "PROTECTED: yes" not in result.stdout or FREEZE_ID not in result.stdout:
            raise RuntimeError("protected path checker did not report the final clean freeze id")

        print("")
        print("STEP 5 - Regenerate and inspect AI-send pack")
        result = run_py(project_root, Path("project_freeze_ledger/freeze_tools/files_needed_for_freezing.py"))
        if result.returncode != 0:
            raise RuntimeError("files_needed_for_freezing.py failed")

        inspect_current_ai_send_pack(project_root)

        print("")
        print("FREEZE OK")
        print(FREEZE_ID)
        print("Final clean project_freeze_ledger tools are frozen.")
        print("Permanent freeze_tools folder contains only the three core tools.")
        return 0

    except Exception as exc:
        print("FREEZE FAILED", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
