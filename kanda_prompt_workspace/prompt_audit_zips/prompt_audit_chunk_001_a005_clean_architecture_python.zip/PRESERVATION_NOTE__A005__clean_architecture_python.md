# PRESERVATION_NOTE__A005__clean_architecture_python

AUDIT_ID: A005
TARGET_PROMPT: 000 3 prompt ideas from  clean architecture (Robert C. Martin).md
TARGET_CANONICAL_ID: clean_architecture_python
RECOMMENDED_ACTION: KEEP
STATUS: audited_candidate

## Purpose

This file records that the Clean Architecture prompt should be preserved essentially as written because its information is important and has clear ownership.

## Preserve

Keep the following content as core canon for this specialist prompt:

- Dependency Rule.
- Four-layer model: Entities, Use Cases, Interface Adapters, Frameworks and Drivers.
- Rule that inner layers must not import frameworks, ORMs, UI, database details, or external transport details.
- Boundary interfaces defined inward and implemented outward.
- Dependency injection and composition root.
- Plain data crossing boundaries.
- Layer-specific testing strategy.
- Output format requiring layer labels, dependency-direction explanation, composition root, and tests.

## Optional future cleanup only

Optional, non-blocking improvements:

1. Add metadata header.
2. Add explicit ownership boundary:
   - This prompt owns architecture boundaries and dependency direction.
   - It does not own detailed refactoring workflow, detailed pytest strategy, performance optimization, deployment, security, observability, or lifecycle governance.
3. If desired, soften examples without weakening the Dependency Rule.

No required update is needed before using this prompt as an audited candidate.
