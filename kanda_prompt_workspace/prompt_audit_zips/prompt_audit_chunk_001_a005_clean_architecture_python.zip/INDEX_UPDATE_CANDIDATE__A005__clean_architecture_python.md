# INDEX_UPDATE_CANDIDATE__A005__clean_architecture_python

AUDIT_ID: A005
TARGET_CANONICAL_ID: clean_architecture_python
SOURCE_PROMPT: 000 3 prompt ideas from  clean architecture (Robert C. Martin).md
NAVIGATION_INDEX_EFFECT: ADD_OR_UPDATE_ACTIVE_CANDIDATE
HUMAN_APPROVAL_REQUIRED: YES, before editing the navigation index

## Suggested active catalog entry

| canonical_id | filename | type | group | load_mode | use_when | related_prompts | status |
|---|---|---|---|---|---|---|---|
| clean_architecture_python | 000 3 prompt ideas from  clean architecture (Robert C. Martin).md | specialist_prompt | architecture | on_request | Use when designing or reviewing Python architecture for dependency direction, layer boundaries, framework isolation, use cases, entities, adapters, composition root, and dependency injection. | clean_code_python; refactoring_fowler_python; design_patterns_python; poeaa_python; testing_python_pytest | audited_candidate |

## Routing notes

- If the request is mostly about local readability, naming, docstrings, or function clarity, route to Clean Code instead or in addition.
- If the request is mostly about changing existing code safely, route to Refactoring instead or in addition.
- If the request is mostly about enterprise persistence patterns such as Unit of Work, Data Mapper, Identity Map, or CQRS, route to PoEAA instead or in addition.
- If the request is mostly about pattern selection, route to Design Patterns instead or in addition.
- If the request is mostly about tests, route to Testing instead or in addition.

## Do not activate yet if

- A human chooses to consolidate all architecture and enterprise persistence material into a different owner prompt.
- Later audit finds a stronger, newer Clean Architecture prompt that supersedes this one.
