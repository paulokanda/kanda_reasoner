# Index Update Candidate — A025 SRE Python

## Add / update index entry

- Prompt ID: A025
- Canonical name: Site Reliability Engineering (SRE) for Python
- File: `000 23 Site Reliability Engineering (SRE) Betsy Beyer.md`
- Classification: SPECIALIST_PROMPT
- Status: audited_candidate_after_update

## Route this prompt when the user asks for

- production readiness
- SLOs / SLIs / error budgets
- incident management
- alerting strategy
- runbooks
- toil automation
- load testing / capacity planning
- chaos engineering
- canary rollout / rollback planning

## Do not route this prompt as the primary owner for

- concrete logging/metrics/tracing implementation: use Observable Python
- retry/circuit-breaker/idempotency design: use Resilient Python
- Docker/Kubernetes/CI/CD mechanics: use Deployable Python
- algorithmic profiling or optimization: use High Performance Python
- burnout/team dynamics/focus culture: use Peopleware
