# Update Recommendation — A025 SRE Python

## Recommendation

Adopt the updated version as the active SRE prompt.

## Reason

The source prompt is valuable and should stay active. The update makes it easier to route tasks correctly by adding metadata and clarifying that this prompt governs reliability decisions, not low-level implementation details owned by Observability, Resilience, Deployment, Performance, or Peopleware prompts.

## Replacement target

Replace or supersede:

`000 23 Site Reliability Engineering (SRE) Betsy Beyer.md`

with the updated file in:

`03_UPDATED_PROMPTS/000 23 Site Reliability Engineering (SRE) Betsy Beyer.md`
