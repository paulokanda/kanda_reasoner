# Audit Report — A025 Site Reliability Engineering Python

## Source file

`000 23 Site Reliability Engineering (SRE) Betsy Beyer.md`

## Decision

UPDATE

## Classification

SPECIALIST_PROMPT

## Status after audit

audited_candidate_after_update

## Scope ownership

This prompt owns production reliability governance for Python applications:

- SLIs and SLOs
- error budgets
- toil automation
- observability strategy from an SRE perspective
- incident management and blameless postmortems
- capacity planning and load testing
- chaos engineering
- canary/progressive rollout and rollback plans
- production runbooks

## Overlap review

Adjacent prompt boundaries:

- Observable Python owns concrete instrumentation details.
- Resilient Python owns application failure handling primitives.
- Deployable Python owns deployment mechanics.
- High Performance Python owns profiling and optimization.
- Peopleware owns team/work environment and burnout prevention.

No integration candidate was required. The overlaps are relationship notes, not conflicts.

## Update performed

- Added metadata frontmatter.
- Added ownership boundary.
- Added relationship notes to adjacent prompts.
- Preserved the original SRE content.

## Final recommendation

Keep as active specialist prompt and add to the navigation index under production readiness / operations / reliability governance.
