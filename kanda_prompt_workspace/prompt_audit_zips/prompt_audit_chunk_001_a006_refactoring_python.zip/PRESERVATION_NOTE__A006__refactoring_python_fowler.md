# PRESERVATION NOTE - A006 - Refactoring Python Fowler

Decision: KEEP.

This prompt should be preserved because it contains important, non-duplicated guidance for safe refactoring.

The most important preserved ideas are:

1. Refactoring must preserve behavior.
2. Feature work and refactoring work must be separated.
3. Tests are the safety net; missing tests require characterization tests.
4. Refactoring must be driven by named smells, not style preference.
5. Refactoring should happen in small reversible steps.
6. The AI should show one step at a time with before/after and verification.
7. The session should stop when the triggering smell is gone, not when the code becomes theoretically perfect.

No integration candidate was needed.

Optional clarification for a future version:

- Replace literal `commit after each successful step` with `recommend or prepare a VCS checkpoint after each successful step unless the user grants commit authority`.

This clarification is not mandatory for the prompt to remain useful.
