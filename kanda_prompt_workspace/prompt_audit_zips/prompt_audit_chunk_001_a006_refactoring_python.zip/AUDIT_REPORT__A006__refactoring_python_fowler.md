# AUDIT REPORT - A006 - Refactoring Python Fowler

## Audit metadata

- AUDIT_ID: A006
- PROMPT_FILENAME: `000 4 Prompt Core Refactoring Principles (Fowler).md`
- CANONICAL_ID: `refactoring_python_fowler`
- DECLARED_VERSION: not declared in source file
- DETECTED_TYPE: `SPECIALIST_PROMPT` / `PROTOCOL`
- DETECTED_GROUP: `IMPLEMENTATION_REFACTORING`
- DETECTED_SCOPE: `project_agnostic`
- AUDIT_STATUS: `audited_candidate`
- RECOMMENDED_DECISION: `KEEP`
- DECISION_GATE: `CLEAR`
- HUMAN_DECISION_REQUIRED: `NO`
- AUDIT_DATE: 2026-06-11

## Single responsibility

PASS.

This prompt has one clear responsibility: guide the AI through safe, behavior-preserving Python refactoring using Martin Fowler-style smell detection, small named transformations, test safety, and stopping criteria.

## Important content preserved

The prompt should be kept because it owns rules that no other prompt owns as directly:

- Behavior preservation: refactoring must not change external behavior.
- Two-hat rule: separate feature work from refactoring work.
- Small reversible steps.
- Smell-driven refactoring, not fashionable cleanup.
- Characterization tests when tests are missing.
- Before/after step format.
- Named Fowler mechanics such as Extract Method, Rename, Move Function, Introduce Parameter Object.
- Anti-patterns: big-bang refactoring, mixing feature work and refactoring, refactoring without tests.
- Stopping criteria: stop when the triggering smell is gone and the original change is easier.
- Campsite rule: leave code slightly cleaner, not perfectly clean.

## Related prompts inspected

| Related prompt | Relationship | Final overlap decision |
|---|---|---|
| `000 2 prompt from Clean Code (Robert C. Martin).md` | Clean Code owns local readability rules. Refactoring uses those rules during transformations. | Complementary |
| `000 3 prompt ideas from clean architecture (Robert C. Martin).md` | Clean Architecture owns dependency direction and layers. Refactoring may improve architecture, but does not own architecture canon. | Complementary |
| `000 8 Python Testing with pytest (Brian Okken) Prompt.md` | Testing owns deep pytest, property, mutation, fixture, and test architecture practices. Refactoring owns tests as safety harness before behavior-preserving change. | Complementary |
| `000 5 Design Patterns Erich Gamma.md` | Design Patterns owns when to use/avoid patterns. Refactoring may introduce a pattern only when a smell justifies it. | Complementary |
| `000 6 Patterns of Enterprise Application Architecture by Martin Fowler.md` | PoEAA owns enterprise persistence/domain/session patterns. Refactoring may move toward those patterns, but does not own them. | Complementary |
| `000 17 Sustaining Python Lifecycle, Versioning, Deprecation & Legacy Code Prompt.md` | Lifecycle owns public API deprecation and legacy evolution. Refactoring references deprecation only when interface behavior would change. | Complementary |

RELATED_PROMPT_CONTENT_REVIEWED: YES.

## Overlap analysis

No duplicate owner conflict found.

The prompt intentionally says it complements Clean Code and Clean Architecture. That is acceptable because it describes load relationship, not ownership takeover. The prompt's distinctive ownership is the transformation journey: smell report -> safety check -> plan -> one step -> verify -> repeat -> final code.

## Project leakage check

PASS.

No project-specific paths, package names, local machine commands, or Reasoner-specific facts were found.

## Conflict review

CONFLICTS_FOUND: NO.

Potential wording to interpret carefully:

- `Commit after each successful step` should be read as a recommended human/VCS checkpoint, not as permission for the AI to perform a commit unless explicitly allowed by the user.
- `Proceed only after the user agrees` applies to risky refactoring without tests. It should not prevent a best-effort analysis report when the user asks only for audit or planning.

These are interpretation notes, not blockers.

## Dissonant logic extraction

DISSONANT_LOGIC_FOUND: NO.

No separate integration candidate was created. The short Clean Code / Clean Architecture integration table belongs here because it explains how refactoring supports those principles without trying to own them.

## Recommended decision

KEEP.

This prompt is valuable enough to preserve as a specialist prompt. No mandatory update is required before cataloging it as an audited candidate.

## Optional future update

A future cleanup pass may add a metadata header and clarify that VCS commits are recommended checkpoints unless the user explicitly grants write/commit authority. This is optional and not required for preservation.

## Navigation index effect

NAVIGATION_INDEX_EFFECT: ADD.

Add this prompt as the active route for requests involving:

- refactor code
- improve existing code without changing behavior
- detect code smells
- safe cleanup
- characterization tests before refactor
- Fowler refactoring mechanics
- separate feature work from refactoring work

## Final audit recommendation

Preserve `000 4 Prompt Core Refactoring Principles (Fowler).md` as an audited specialist prompt. It should be loaded after or alongside Clean Code and Clean Architecture when the user asks to modify existing code safely, especially when behavior preservation matters.
