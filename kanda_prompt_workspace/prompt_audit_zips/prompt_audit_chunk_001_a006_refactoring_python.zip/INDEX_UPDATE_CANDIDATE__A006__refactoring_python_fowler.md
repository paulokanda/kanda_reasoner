# INDEX UPDATE CANDIDATE - A006 - Refactoring Python Fowler

## Proposed active catalog entry

| Field | Value |
|---|---|
| prompt_id | `refactoring_python_fowler` |
| filename | `000 4 Prompt Core Refactoring Principles (Fowler).md` |
| type | `SPECIALIST_PROMPT` / `PROTOCOL` |
| group | `IMPLEMENTATION_REFACTORING` |
| scope | `project_agnostic` |
| load_mode | `on_request` |
| status | `audited_candidate` |
| depends_on | `clean_code_python`, `clean_architecture_python` when architecture-sensitive |
| related_prompts | `python_testing_pytest`, `design_patterns_python`, `poeaa_python`, `sustaining_python_lifecycle` |

## Use when

Load this prompt when the user asks to:

- refactor existing Python code;
- improve code while preserving behavior;
- identify code smells;
- split a risky change into safe steps;
- write characterization tests before modifying legacy code;
- separate feature work from refactoring work;
- use Fowler-style named refactoring mechanics.

## Do not use when

Do not load this prompt for:

- brand-new greenfield implementation with no existing code to transform;
- pure architecture design before code exists;
- testing strategy as the main task;
- performance optimization unless the user is specifically asking to restructure existing code safely.

## Index update status

This is a candidate only. The Navigation Index should not be edited automatically during audit.
