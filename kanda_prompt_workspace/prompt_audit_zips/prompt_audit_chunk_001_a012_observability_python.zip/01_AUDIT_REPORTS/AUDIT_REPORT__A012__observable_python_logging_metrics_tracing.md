# AUDIT REPORT - A012 - observable_python_logging_metrics_tracing

AUDIT_ID: A012
PROMPT_FILENAME: 000 10 Observable Python Logging, Metrics & Tracing Prompt.md
CANONICAL_ID: observable_python_logging_metrics_tracing
DECLARED_VERSION: not declared in file
SCOPE: project_agnostic
TYPE: SPECIALIST_PROMPT
SINGLE_RESPONSIBILITY_PASS: YES
PROJECT_LEAKAGE_FOUND: NO
RELATED_PROMPT_CONTENT_REVIEWED: YES

## Related prompts inspected

- 000 9 Secure Python App Security & Threat Prevention Prompt.md
- 000 7 High Performance Python Prompt for AI Code Generation.md
- 000 0 Kubernetes Up and Running.md
- 000 12 Resilient Python Error Handling, Retries & Circuit Breakers Prompt.md
- 000 8 Python Testing with pytest (Brian Okken) Prompt.md

## Ownership summary

This prompt owns observability for Python systems: structured logging, metrics, tracing, correlation IDs, health checks, alerting, SLIs/SLOs, dashboards, operational considerations, and observability output format.

It does not own:

- secure coding or threat modelling, owned by the Security prompt;
- runtime failure survival, owned by the Resilience prompt;
- deployment manifests and orchestration, owned by the Deployment prompt;
- performance optimization, owned by the High Performance prompt;
- test strategy, owned by the Testing prompt.

## Overlap analysis

| Related prompt | Relationship | Decision |
|---|---|---|
| Security | Complementary overlap around not logging secrets | Keep here as observability safety rule; Security remains owner of broader data protection |
| Deployment | Complementary overlap around health checks, metrics endpoints, Prometheus stack | Keep; Deployment consumes observability requirements at platform level |
| Resilience | Complementary overlap around health/readiness and failure visibility | Keep; Resilience owns failure behavior, Observability owns visibility |
| Performance | Complementary overlap around overhead and metrics | Keep; Performance owns optimization, Observability owns measurement signals |
| Testing | Complementary overlap around verification | Keep; Testing owns automated tests |

## Dissonant logic extracted

None.

## Integration candidates created

None.

## Recommended decision

KEEP.

## Status after audit

audited_candidate.

## Human decision required

NO.

## Navigation index update needed

YES - add as an active specialist route after human acceptance.

## Final audit recommendation

Preserve this prompt as a specialist prompt for Python observability. No content deletion is recommended. Optional future normalization may add a metadata header, but the current content is useful and has clear ownership.
