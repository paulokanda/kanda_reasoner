# INDEX UPDATE CANDIDATE - A012

Prompt ID: observable_python_logging_metrics_tracing
Filename: 000 10 Observable Python Logging, Metrics & Tracing Prompt.md
Classification: SPECIALIST_PROMPT
Status after audit: audited_candidate
Recommended index action: ADD active specialist route after human acceptance

## Use when

Use this prompt when the task involves:

- structured logging;
- metrics;
- distributed tracing;
- correlation IDs;
- health checks;
- SLIs/SLOs;
- alerting;
- Grafana/Prometheus/Loki/Tempo/Jaeger style observability;
- making a Python service understandable in production.

## Related prompts

- secure_python_app_security_threat_prevention
- deployable_python_containers_orchestration_cicd
- resilient_python_error_handling_retries_circuit_breakers
- high_performance_python
- testing_python_pytest

## Do not use as owner for

- threat modelling or security controls;
- retry/circuit breaker behavior;
- Kubernetes deployment design;
- pytest strategy;
- performance optimization.
