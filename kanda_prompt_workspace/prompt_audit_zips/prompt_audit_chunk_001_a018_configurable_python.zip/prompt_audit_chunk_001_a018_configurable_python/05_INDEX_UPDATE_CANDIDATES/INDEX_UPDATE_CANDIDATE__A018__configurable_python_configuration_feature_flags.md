# INDEX_UPDATE_CANDIDATE__A018__configurable_python_configuration_feature_flags

Audit ID: A018
Canonical ID: configurable_python_configuration_management_feature_flags
Prompt file: 000 16 Configurable Python Configuration Management & Feature Flags Prompt.md
Recommended catalog section: SPECIALIST_PROMPTS
Status: audited_candidate
Load mode: on_request

## Use when

Load this prompt when the task involves:

- configuration management;
- environment variables;
- `.env` files;
- Pydantic Settings;
- secret-loading strategy;
- feature flags or release toggles;
- runtime configuration reload;
- documenting environment variables;
- config validation and fail-fast startup.

## Do not use as primary prompt when

- the task is general security threat modelling: use Security prompt;
- the task is deployment manifests or CI/CD: use Deployment prompt;
- the task is retries, circuit breakers, or fallback behavior: use Resilience prompt;
- the task is logging, metrics, or tracing implementation: use Observability prompt.
