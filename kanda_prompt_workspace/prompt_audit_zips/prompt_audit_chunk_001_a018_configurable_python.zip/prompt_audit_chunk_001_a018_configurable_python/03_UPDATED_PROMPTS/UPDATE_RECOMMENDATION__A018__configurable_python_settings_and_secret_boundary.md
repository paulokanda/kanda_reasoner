# UPDATE_RECOMMENDATION__A018__configurable_python_settings_and_secret_boundary

Audit ID: A018
Target prompt: 000 16 Configurable Python Configuration Management & Feature Flags Prompt.md
Decision: UPDATE

## Update summary

The prompt is valuable and should remain in the library. The update is limited to clarity and correctness:

1. Keep the configuration-management and feature-flag content.
2. Clarify that non-secret config is externalized through environment variables, while production secrets should preferably come from secret managers or mounted secret files.
3. Avoid contradiction between Twelve-Factor configuration and secret-management guidance.
4. Update the Pydantic Settings example to avoid mixing modern `model_config = SettingsConfigDict(...)` with legacy `class Config`.
5. Add ownership boundary so the prompt does not duplicate Security, Deployment, Observability, or Resilience.

## Final action

Use the updated real prompt file included in `03_UPDATED_PROMPTS`.
