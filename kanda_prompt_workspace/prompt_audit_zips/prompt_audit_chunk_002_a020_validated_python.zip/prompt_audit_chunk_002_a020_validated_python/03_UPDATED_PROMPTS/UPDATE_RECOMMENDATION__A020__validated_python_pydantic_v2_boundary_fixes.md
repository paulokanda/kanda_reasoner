# UPDATE RECOMMENDATION - A020

## Recommended action

Replace or stage the original file with the updated prompt in:

`03_UPDATED_PROMPTS/000 18 Validated Python Data Validation, Serialisation & Type Safety Promp.md`

## Why

The prompt is important and should remain in the professional Python prompt library, but it needed consistency fixes around Pydantic v2 and validation boundaries.

## Keep unchanged

The following conceptual content should remain preserved:

- Validate at the edge.
- Pydantic as the modern default for Python boundary validation.
- Runtime type checking with typeguard/beartype when needed.
- TypedDict and Protocols for type safety.
- Serialization format selection.
- Deserialization safety and explicit rejection of pickle for untrusted data.
