# INDEX UPDATE CANDIDATE - A020

Add or update this entry in the Prompt Navigation Index:

## A020 - Validated Python: Data Validation, Serialisation & Type Safety

- **File:** `000 18 Validated Python Data Validation, Serialisation & Type Safety Promp.md`
- **Classification:** SPECIALIST_PROMPT
- **Status:** audited_candidate_after_update
- **Use when:** The task involves data contracts, Pydantic models, validation at system boundaries, serialization/deserialization safety, TypedDict, Protocols, runtime type checking, or safe parsing of external input.
- **Do not use as primary prompt when:** The main task is API routing/interface design, security threat modeling, testing strategy, performance profiling, or environment configuration. Use the relevant specialist prompt first and this prompt as a complement.
- **Related prompts:** Interface Python, Secure Python, Testing Python, High Performance Python, Configurable Python.
