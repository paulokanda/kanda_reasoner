# AUDIT REPORT - A020 - Validated Python

## Source file

`000 18 Validated Python Data Validation, Serialisation & Type Safety Promp.md`

## Decision

UPDATE

## Classification

SPECIALIST_PROMPT

## Scope ownership

This prompt owns data validation, serialisation, deserialisation safety, runtime type-safety guidance, schema contracts, and data boundary parsing.

## Reason for update

The prompt is valuable and should be kept, but several examples needed correction:

1. The first Pydantic example used `validator`, which is Pydantic v1 style, while the prompt itself states that Pydantic v2 should use `field_validator` and `model_validator`.
2. The coupon validator performed a database lookup inside schema validation, which contradicts the prompt's later anti-pattern warning against checking the database inside validators.
3. The `UserProfile` example referenced `parental_consent` without defining the field.
4. The prompt did not have an explicit ownership boundary.

## Update performed

- Added metadata frontmatter.
- Added an ownership boundary.
- Replaced `validator` with `field_validator`.
- Replaced database-backed coupon validation with pure syntax validation.
- Added `parental_consent` to the model validator example.
- Added docstrings and type clarity to example code.

## Integration candidates

None.

## Final status

`audited_candidate_after_update`
