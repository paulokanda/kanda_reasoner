# INDEX UPDATE CANDIDATE - A002 - deployable_python_containers_orchestration_cicd

Audit ID: A002
Canonical ID: deployable_python_containers_orchestration_cicd
Prompt filename: 000 0 Kubernetes Up and Running.md

## Proposed active catalog entry

| Field | Value |
|---|---|
| canonical_id | deployable_python_containers_orchestration_cicd |
| file | 000 0 Kubernetes Up and Running.md |
| type | SPECIALIST_PROMPT |
| group | DEPLOYMENT |
| scope | project_agnostic |
| load_mode | on_request |
| status | audited_candidate |

## Use when

Load this prompt when the user asks for:

- Dockerfile creation or review for Python apps
- Kubernetes manifests, probes, resources, HPA, PDB, NetworkPolicy, or Ingress
- CI/CD pipeline design for test, build, push, deploy
- infrastructure-as-code deployment planning
- production readiness checks
- zero-downtime deployment strategy
- rollback plan
- deployment secrets injection
- release migration execution strategy

## Do not use when

Do not use as the main prompt for:

- application security design -> use Secure Python
- structured logging/metrics/tracing design -> use Observable Python
- database schema/query optimisation -> use Data-Aware Python
- retry/circuit-breaker/idempotency design -> use Resilient Python
- application configuration object and feature flag model -> use Configurable Python

Use it together with those prompts only when deployment intersects those concerns.

## Index action

ADD_OR_UPDATE_ACTIVE_CATALOG_ENTRY after the minor Dockerfile healthcheck update is accepted.
