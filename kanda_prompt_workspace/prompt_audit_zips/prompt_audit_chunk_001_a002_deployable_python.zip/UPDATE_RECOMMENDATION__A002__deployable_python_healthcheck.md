# UPDATE RECOMMENDATION - A002 - deployable_python_containers_orchestration_cicd

Source prompt: 000 0 Kubernetes Up and Running.md
Canonical ID: deployable_python_containers_orchestration_cicd
Reason: Dockerfile healthcheck currently uses curl without installing curl in the runtime image.

## Recommended change

Replace this Dockerfile healthcheck:

```dockerfile
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:8000/health/live || exit 1
```

With this stdlib-only healthcheck:

```dockerfile
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health/live', timeout=2)" || exit 1
```

## Reason

The prompt uses `python:3.12-slim` as runtime image. That image should not be assumed to contain curl. The stdlib-only healthcheck avoids installing an additional OS package.

## Decision

This is a minor update. It does not change the prompt's scope, ownership, or canonical role.
