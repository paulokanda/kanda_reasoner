# INDEX UPDATE CANDIDATE — A021 — Complementary Books Reference

## Recommended navigation index entry

```text
ID: A021
File: 000 19 complementry books.md
Title: Complementary Books Planning Note
Classification: PROJECT_REFERENCE / HISTORICAL_PLANNING_NOTE
Status: deprecated_historical_reference
Active prompt: no
Primary use: Trace why DDD, Legacy Code, Pragmatic Programmer, SRE, and Peopleware prompts were added.
Do not use for: Direct code generation, active prompt stack loading, or specialist execution.
Related active prompts:
- A022 Working Effectively with Legacy Code
- A023 Domain-Driven Design
- A024 The Pragmatic Programmer
- A025 Site Reliability Engineering
- A026 Peopleware
```

## Index placement

Place under a section such as:

```text
Historical / Planning / Reference Notes
```

Do not place under:

```text
Active Specialist Prompts
```
