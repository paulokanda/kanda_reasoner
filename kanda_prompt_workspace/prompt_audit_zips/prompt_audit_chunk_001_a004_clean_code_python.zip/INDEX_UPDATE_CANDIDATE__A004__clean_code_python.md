# INDEX_UPDATE_CANDIDATE__A004__clean_code_python

AUDIT_ID: A004
TARGET_CANONICAL_ID: clean_code_python
SOURCE_PROMPT: 000 2 prompt from Clean Code (Robert C. Martin).md
NAVIGATION_INDEX_EFFECT: ADD_OR_UPDATE_ACTIVE_CANDIDATE
HUMAN_APPROVAL_REQUIRED: YES, before editing the navigation index

## Suggested active catalog entry

| canonical_id | filename | type | group | load_mode | use_when | related_prompts | status |
|---|---|---|---|---|---|---|---|
| clean_code_python | 000 2 prompt from Clean Code (Robert C. Martin).md | specialist_prompt | implementation_quality | on_request | Use when generating or reviewing Python code for readability, naming, small functions, comments/docstrings, formatting, error handling basics, cohesive classes, type hints, and basic test readability. | clean_architecture_python; refactoring_fowler_python; testing_python_pytest; design_patterns_python; high_performance_python | audited_candidate |

## Routing notes

- If the request is mostly about dependency direction, architecture layers, boundaries, or composition root, route to Clean Architecture instead or in addition.
- If the request is mostly about modifying existing code safely, route to Refactoring instead or in addition.
- If the request is mostly about writing or reviewing tests, route to Testing instead or in addition.
- If the request is mostly about speed, memory, concurrency, or profiling, route to High Performance instead or in addition.

## Do not activate yet if

- The update recommendation has not been applied.
- A human wants a stricter literal Clean Code style instead of pragmatic Python defaults.
