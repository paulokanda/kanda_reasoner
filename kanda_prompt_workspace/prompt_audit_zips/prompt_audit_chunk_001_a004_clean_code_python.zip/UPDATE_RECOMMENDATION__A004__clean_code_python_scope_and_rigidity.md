# UPDATE_RECOMMENDATION__A004__clean_code_python_scope_and_rigidity

AUDIT_ID: A004
TARGET_PROMPT: 000 2 prompt from Clean Code (Robert C. Martin).md
TARGET_CANONICAL_ID: clean_code_python
RECOMMENDED_ACTION: UPDATE
STATUS: pending_update

## Purpose

This file records recommended edits for the Clean Code Python prompt before it is promoted from audited_candidate to active.

## Required updates

1. Add metadata header.

Suggested metadata:

```yaml
---
audit_id: A004
canonical_id: clean_code_python
version: 1.0
status: audited_candidate
project_agnostic: true
type: specialist_prompt
group: implementation_quality
load_mode: on_request
source_inspiration:
  - Robert C. Martin Clean Code
  - PEP 8
  - PEP 257
  - modern Python type hinting
---
```

2. Add ownership boundary.

Suggested text:

```text
This prompt owns local code readability, naming, function clarity, comments,
formatting, error handling basics, class cohesion, type-hint discipline, and
basic test readability.

It does not own full software architecture, refactoring workflow, advanced
pytest strategy, security, observability, performance optimization, database
design, deployment, or lifecycle governance. For those tasks, load the
corresponding specialist prompt.
```

3. Soften overly absolute rules.

Recommended edits:

- Change "Maximum 3 arguments" to "Prefer 0-2 arguments. Treat 3 or more as a design smell unless the grouping is naturally cohesive."
- Change "Never chain more than one dot" to "Avoid deep object navigation across unrelated objects; prefer asking the owning object for the needed behavior. Do not apply this mechanically to fluent APIs, builders, or well-known library chains."
- Change "One assert per test" to "One behavior per test; multiple asserts are acceptable when they verify one coherent behavior."

4. Fix typo.

- Replace "doctrings" with "docstrings".

5. Add specialist routing note.

Suggested text:

```text
When the task is primarily about architectural boundaries, load the Clean
Architecture prompt.
When the task is primarily about changing existing code safely, load the
Refactoring prompt.
When the task is primarily about tests, load the Testing prompt.
When the task is primarily about speed, memory, or scalability, load the
High Performance prompt.
```

## Integration candidates

None. The related prompts already exist and own their deeper domains. No snippet needs extraction into a separate target prompt at this time.
