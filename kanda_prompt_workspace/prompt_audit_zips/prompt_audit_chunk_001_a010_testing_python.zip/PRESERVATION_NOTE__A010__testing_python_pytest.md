# PRESERVATION NOTE - A010

Prompt: 000 8 Python Testing with pytest (Brian Okken) Prompt.md
Canonical ID: testing_python_pytest_quality
Decision: KEEP

## Why preserve

This prompt contains important specialist testing knowledge that is not safely reducible to another prompt. It should remain a standalone prompt because testing is a cross-cutting discipline with its own workflows, tools, and anti-patterns.

## Important content preserved

- pytest as the preferred modern Python testing framework
- AAA pattern
- testing pyramid
- unit, integration, and end-to-end testing balance
- Hypothesis/property-based testing
- fuzzing
- mutation testing
- test doubles: mocks, stubs, fakes, spies
- pytest fixtures and parametrization
- testing toolkit
- anti-pattern table
- workflow for testing requests
- output format for testing responses

## Boundary with other prompts

Clean Code may mention basic test readability, but this prompt owns professional test design and test quality.

Refactoring may require tests before refactoring, but this prompt owns the mechanics and strategy for creating those tests.

Security may require security tests, but this prompt owns how those tests are structured and automated.

Performance may require benchmarks, but this prompt owns test/benchmark integration conventions.
