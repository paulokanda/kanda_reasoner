# INDEX UPDATE CANDIDATE - A010

## Candidate prompt

Prompt filename: 000 8 Python Testing with pytest (Brian Okken) Prompt.md
Canonical ID: testing_python_pytest_quality
Recommended status: audited_candidate
Recommended route type: on_request specialist prompt

## Add to active/specialist catalog after human acceptance

| Route trigger | Load this prompt |
|---|---|
| User asks for pytest tests | testing_python_pytest_quality |
| User asks for unit, integration, or end-to-end test design | testing_python_pytest_quality |
| User asks for fixtures, parametrization, mocks, fakes, or test doubles | testing_python_pytest_quality |
| User asks for property-based testing or Hypothesis | testing_python_pytest_quality |
| User asks for fuzzing or mutation testing | testing_python_pytest_quality |
| User asks whether tests are strong enough | testing_python_pytest_quality |
| Refactoring task requires characterization tests | testing_python_pytest_quality plus refactoring_python_fowler |
| Security task requires tests for controls | testing_python_pytest_quality plus secure_python_application_security |
| Performance task requires benchmark or regression tests | testing_python_pytest_quality plus high_performance_python |

## Suggested use_when text

Use when the task involves writing, reviewing, organizing, strengthening, or validating Python tests. This prompt owns pytest strategy, test pyramid, fixtures, parametrization, property-based testing, fuzzing, mutation testing, test doubles, and test anti-patterns.

## Do not use as primary route for

- General code readability: use Clean Code prompt.
- Behavior-preserving refactoring workflow: use Refactoring prompt, with Testing as support.
- Security architecture: use Security prompt, with Testing as support.
- Performance optimization: use Performance prompt, with Testing as support for benchmarks.

## Index edit status

This is a suggestion only. Do not edit the navigation index directly during this audit session.
