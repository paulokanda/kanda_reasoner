# INDEX UPDATE CANDIDATE - A019

Suggested prompt index entry:

```yaml
prompt_id: sustaining_python_lifecycle_versioning_deprecation_legacy_code
display_name: Sustaining Python - Lifecycle, Versioning, Deprecation & Legacy Code
file: 000 17 Sustaining Python Lifecycle, Versioning, Deprecation & Legacy Code Prompt.md
classification: SPECIALIST_PROMPT
status: audited_candidate
use_when:
  - planning semantic versioning
  - deprecating or removing APIs
  - preserving backward compatibility
  - rescuing legacy Python code
  - handling abandoned dependencies
  - planning data migrations and rollbacks
  - defining API or feature sunset policies
  - maintaining multiple supported versions
do_not_use_when:
  - the task is only code style or readability
  - the task is only test-writing mechanics
  - the task is only API route design
  - the task is only runtime configuration or feature-flag mechanics
related_prompts:
  - refactoring_python
  - testing_python_pytest
  - secure_python_app_security
  - configurable_python_configuration_feature_flags
  - interface_python_rest_graphql_api_design
```
```
