# UPDATE RECOMMENDATION — A023 — Domain-Driven Design Python

## Recommendation

Use the updated prompt file in `03_UPDATED_PROMPTS` as the canonical candidate.

## Reason

The source prompt was valuable and mostly correct, but it needed prompt-library metadata and an explicit ownership boundary to prevent overlap with Clean Architecture, PoEAA, Testing, Legacy Code, and Data-Aware Python.

## Applied update type

Structural metadata and prompt-governance clarification. No major content removal.
