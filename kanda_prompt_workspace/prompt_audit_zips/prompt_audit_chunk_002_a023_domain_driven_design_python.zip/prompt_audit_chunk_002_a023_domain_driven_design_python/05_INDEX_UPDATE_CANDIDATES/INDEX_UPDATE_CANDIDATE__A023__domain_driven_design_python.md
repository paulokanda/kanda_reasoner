# INDEX UPDATE CANDIDATE — A023 — Domain-Driven Design Python

## Add or update index entry

### A023 — Domain-Driven Design Python

- **File:** `000 21 Domain-Driven Design - Eric Evans.md`
- **Classification:** SPECIALIST_PROMPT
- **Status:** audited_candidate_after_update
- **Use when:** The task involves business-language modeling, bounded contexts, aggregates, entities, value objects, domain services, domain events, repositories, anti-corruption layers, or deciding whether DDD is justified.
- **Do not use when:** The task is simple CRUD, low-domain-complexity scripting, pure database optimization, pure refactoring mechanics, or pure infrastructure deployment.
- **Adjacent prompts:** Clean Architecture, PoEAA, Testing, Legacy Code, Data-Aware Python, Refactoring.
