# AUDIT REPORT — A023 — Domain-Driven Design Python

## Target file

`000 21 Domain-Driven Design - Eric Evans.md`

## Decision

UPDATE

## Classification

SPECIALIST_PROMPT

## Status after audit

`audited_candidate_after_update`

## Ownership

This prompt owns Domain-Driven Design for Python systems: Ubiquitous Language, Bounded Contexts, Context Mapping, tactical DDD patterns, Aggregate boundaries, Domain Events, Repository abstraction, Application Services, and Anti-Corruption Layers.

## Related prompts inspected conceptually

- Clean Architecture: owns dependency direction, application layers, and infrastructure boundaries.
- PoEAA: owns enterprise persistence/application patterns that may implement DDD repositories and Unit of Work.
- Testing: owns detailed test design.
- Legacy Code: owns safe changes to untested existing systems.
- Data-Aware Python: owns schema, indexing, query performance, and database optimization.

## Findings

The prompt is valuable and should remain active. It is a specialist prompt, not a general-purpose coding prompt. The original content is strong, especially the distinction between strategic design and tactical modeling, the warning against Java-flavoured over-engineering, the warning that DDD is not for CRUD, and the Anti-Corruption Layer add-on.

## Updates applied

1. Added metadata frontmatter.
2. Added explicit ownership boundary.
3. Clarified relationships to adjacent specialist prompts.
4. Preserved original DDD content and examples.

## Integration candidates

None.

## Final recommendation

Keep this prompt active as the DDD specialist prompt. Use it when domain complexity, business language, bounded contexts, invariants, aggregates, or cross-context translation are central to the task.
