# MANIFEST — A023 Domain-Driven Design Python

- `00_README/README__PROMPT_AUDIT_CHUNK_002_A023.md`
- `01_AUDIT_REPORTS/AUDIT_REPORT__A023__domain_driven_design_python.md`
- `03_UPDATED_PROMPTS/000 21 Domain-Driven Design - Eric Evans.md`
- `03_UPDATED_PROMPTS/UPDATE_RECOMMENDATION__A023__domain_driven_design_metadata_and_boundary.md`
- `05_INDEX_UPDATE_CANDIDATES/INDEX_UPDATE_CANDIDATE__A023__domain_driven_design_python.md`
- `06_INTEGRATION_CANDIDATES/INTEGRATION_CANDIDATE_LEDGER__A023.md`
