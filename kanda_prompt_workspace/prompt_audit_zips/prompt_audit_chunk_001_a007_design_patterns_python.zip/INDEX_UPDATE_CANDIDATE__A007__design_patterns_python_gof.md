# INDEX UPDATE CANDIDATE - A007 - Design Patterns Python GoF

Audit ID: A007
Canonical ID: design_patterns_python_gof
Prompt filename: 000 5 Design Patterns Erich Gamma.md
Status after audit: audited_candidate
Action: ADD ACTIVE ROUTE AFTER HUMAN APPROVAL

## Suggested active catalog entry

| canonical_id | file | type | group | load_mode | use_when | do_not_use_when |
| --- | --- | --- | --- | --- | --- | --- |
| design_patterns_python_gof | 000 5 Design Patterns Erich Gamma.md | specialist_prompt | implementation_patterns | on_request | User asks to apply, avoid, compare, or justify Python design patterns; user needs pragmatic GoF pattern choice; code has object-creation, algorithm-selection, callback/observer, command, adapter, facade, visitor, proxy, or template concerns. | Database persistence patterns -> PoEAA. Dependency-rule layering -> Clean Architecture. Behavior-preserving transformation -> Refactoring. Local readability only -> Clean Code. |

## Related routes

- clean_code_python
- clean_architecture_python
- refactoring_python_fowler
- poeaa_python_enterprise_patterns
- high_performance_python

## Index note

This prompt should be a specialist on-request prompt, not daily-loaded.
