# PRESERVATION NOTE - A007 - Design Patterns Python GoF

Decision: KEEP
Reason: The prompt has high-value specialist content with clear ownership.

Preserve the following important content:

- Patterns solve real problems, not theoretical ones.
- Always consider a simpler Pythonic solution before applying a GoF pattern.
- Functional alternatives can replace many classical behavioral patterns in Python.
- Python built-ins and standard-library idioms often replace formal GoF machinery.
- Anti-patterns such as pattern-itis, singleton abuse, factory overuse, and unnecessary strategy hierarchies must remain explicit.
- Output must include problem statement, alternatives considered, pattern chosen, code, vocabulary comment, test examples, and pitfalls.

No integration candidate is needed.
No merge is recommended.
No deprecation is recommended.

Optional cleanup:

- Remove any stray leading artifact text.
- Add metadata during a later normalization pass.
