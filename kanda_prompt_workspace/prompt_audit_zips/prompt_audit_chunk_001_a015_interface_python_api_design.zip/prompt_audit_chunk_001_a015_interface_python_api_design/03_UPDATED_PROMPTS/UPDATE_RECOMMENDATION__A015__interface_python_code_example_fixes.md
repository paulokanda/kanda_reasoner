# UPDATE RECOMMENDATION - A015 - Interface Python API Design

Decision: UPDATE
Target prompt: 000 13 Interface Python REST, GraphQL & API Design Prompt.md
Updated prompt included: YES

## Update summary

The prompt content should be preserved. Only small code-example corrections were applied.

## Changes applied

1. WebSocket example
   - Added `import logging`.
   - Added `WebSocketDisconnect` import.
   - Added `logger = logging.getLogger(__name__)`.
   - Replaced `print("Client disconnected")` with structured logging-friendly `logger.info("websocket_client_disconnected")`.
   - Added `-> None` return type.

2. Rate limiting example
   - Added `from fastapi import Request`.
   - Added a concrete return type annotation.

3. API security/OAuth2 example
   - Added `from fastapi import Depends, HTTPException`.
   - Added a concrete return type annotation.

## Reason

These changes preserve the prompt's meaning while making the examples more complete and aligned with the surrounding Clean Code, Observability, and API-design prompt standards.
