# INDEX UPDATE CANDIDATE - A015 - Interface Python API Design

Prompt ID: interface_python_api_design
Filename: 000 13 Interface Python REST, GraphQL & API Design Prompt.md
Classification: SPECIALIST_PROMPT
Status after audit: audited_candidate
Route type: on_request

## Use when

Load this prompt when the task involves:

- REST API design
- GraphQL schema/resolver design
- OpenAPI / Swagger specification
- API versioning
- pagination, filtering, sorting
- rate limiting at interface level
- WebSocket, SSE, webhook, or async API design
- request/response schema design
- API documentation and developer-consumer experience

## Related prompts

- secure_python_app_security_threat_prevention
- observable_python_logging_metrics_tracing
- resilient_python_error_handling_retries_circuit_breakers
- testing_python_pytest
- configurable_python_configuration_feature_flags
- deployable_python_containers_orchestration_cicd

## Index action

ADD to active specialist catalog after human accepts A015 updated prompt.
