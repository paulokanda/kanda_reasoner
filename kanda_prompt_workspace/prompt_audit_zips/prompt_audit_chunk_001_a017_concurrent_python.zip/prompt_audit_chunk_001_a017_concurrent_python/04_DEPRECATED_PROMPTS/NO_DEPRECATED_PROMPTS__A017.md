# No deprecated prompts for A017.
