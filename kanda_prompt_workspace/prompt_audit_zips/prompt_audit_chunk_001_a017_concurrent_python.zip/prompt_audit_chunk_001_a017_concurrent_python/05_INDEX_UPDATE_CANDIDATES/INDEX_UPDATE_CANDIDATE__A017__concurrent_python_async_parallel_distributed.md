# INDEX UPDATE CANDIDATE A017 - Concurrent Python

## Candidate action
ADD_OR_UPDATE_ACTIVE_ROUTE

## Prompt filename
000 15 Concurrent Python Async, Parallel & Distributed Computing Prompt.md

## Canonical ID
concurrent_python_async_parallel_distributed

## Type
SPECIALIST_PROMPT

## Group
IMPLEMENTATION / PERFORMANCE / CONCURRENCY

## Load mode
on_request

## Use when
Use this prompt when the task involves async IO, threading, multiprocessing, process pools, worker pools, backpressure, task queues, distributed computing, actor models, race prevention, deadlock prevention, or choosing the correct Python concurrency model.

## Do not use when
Do not use this prompt for general performance optimization unless concurrency is central. Use High Performance Python first for profiling/vectorization/memory optimization. Use Resilience for retries/circuit breakers/fallbacks. Use Observability for metrics/logging/tracing.

## Related prompts
- high_performance_python
- resilient_python_error_handling_retries_circuit_breakers
- observable_python_logging_metrics_tracing
- deployable_python_containers_orchestration_cicd
