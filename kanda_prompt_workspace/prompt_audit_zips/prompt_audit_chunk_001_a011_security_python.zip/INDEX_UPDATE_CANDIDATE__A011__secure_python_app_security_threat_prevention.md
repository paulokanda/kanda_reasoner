# INDEX UPDATE CANDIDATE - A011 - Secure Python App Security & Threat Prevention

## Candidate action

ADD_OR_UPDATE_ACTIVE_CATALOG_ENTRY after human acceptance.

## Proposed catalog entry

| Field | Value |
|---|---|
| prompt_id | secure_python_app_security_threat_prevention |
| file | 000 9 Secure Python App Security & Threat Prevention Prompt.md |
| classification | SPECIALIST_PROMPT |
| group | SECURITY |
| load_mode | on_request |
| use_when | Use when the task involves Python application security, threat modelling, secure coding, authentication, authorization, input validation, injection prevention, cryptography, dependency scanning, secret leakage, XSS, deserialization, file upload safety, or security review. |
| related_prompts | testing_python_pytest; observable_python_logging_metrics_tracing; resilient_python_error_handling_retries_circuit_breakers; interface_python_rest_graphql_api_design; configurable_python_configuration_feature_flags; deployable_python_containers_orchestration_cicd |
| status | audited_candidate |

## Routing notes

- For security test cases, load this prompt plus the Testing prompt.
- For endpoint security, load this prompt plus the API Design prompt.
- For secrets and configuration safety, load this prompt plus the Configuration prompt.
- For production deployment hardening, load this prompt plus the Deployment prompt.
- For secret-safe logging and monitoring, load this prompt plus the Observability prompt.

## Index edit policy

This file is only an index update candidate. Do not edit the Prompt Navigation Index directly during the audit session.
