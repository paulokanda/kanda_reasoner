# PRESERVATION NOTE - A011 - Secure Python App Security & Threat Prevention

## Decision

Preserve the prompt.

## Why it should remain intact

The prompt has high-value specialist content and clear ownership. It covers app-security responsibilities that are not fully owned by any other prompt in the batch:

- threat modelling;
- input validation;
- injection prevention;
- authentication and session safety;
- authorization and IDOR prevention;
- cryptography guardrails;
- dependency and supply-chain scanning;
- output encoding and XSS prevention;
- secret-safe logging;
- secure file handling;
- deserialization safety;
- security-specific response format.

## What not to do

Do not merge this prompt into Testing, Deployment, API Design, or Configuration. Those prompts are related but have different ownership.

## Optional later cleanup

- Add standardized YAML metadata.
- Remove any conversational tail text.
- Reconfirm current-year tool references before changing them.
