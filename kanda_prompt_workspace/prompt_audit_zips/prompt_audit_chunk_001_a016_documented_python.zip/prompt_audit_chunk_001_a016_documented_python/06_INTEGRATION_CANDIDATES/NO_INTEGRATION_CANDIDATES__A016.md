# No integration candidates for A016
