# INDEX UPDATE CANDIDATE - A016 - Documented Python

## Candidate route

- prompt_id: documented_python_docs_developer_experience_onboarding
- filename: 000 14  Documented Python Docs, Developer Experience & Onboarding Prompt.md
- classification: SPECIALIST_PROMPT
- group: DOCUMENTATION_AND_DEVELOPER_EXPERIENCE
- load_mode: on_request

## Use when

Load this prompt when the task involves:

- README creation or cleanup.
- Project documentation.
- Docstrings and API reference generation.
- MkDocs or Sphinx documentation sites.
- Architecture Decision Records.
- Contributing guides.
- Local onboarding automation.
- Developer experience and project discoverability.

## Do not use when

- The task is pure API design: use the API Design prompt.
- The task is deployment execution: use the Deployment prompt.
- The task is security policy: use the Security prompt.
- The task is versioning or deprecation policy: use the Lifecycle prompt.
