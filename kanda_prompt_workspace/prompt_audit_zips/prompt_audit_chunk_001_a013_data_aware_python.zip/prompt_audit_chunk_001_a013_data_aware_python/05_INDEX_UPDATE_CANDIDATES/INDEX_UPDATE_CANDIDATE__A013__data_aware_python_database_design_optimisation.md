# INDEX_UPDATE_CANDIDATE__A013__data_aware_python_database_design_optimisation

## Candidate active catalog entry

| Field | Value |
|---|---|
| prompt_id | data_aware_python_database_design_optimisation |
| file_name | 000 11 Data-Aware Python Database Design & Optimisation Prompt.md |
| status | audited_candidate |
| type | specialist_prompt |
| group | database / data_layer |
| load_mode | on_request |
| use_when | Database schema design, indexing, SQLAlchemy, query optimization, EXPLAIN plans, migrations, connection pooling, SQL vs NoSQL, read replicas, partitioning, sharding, database bottlenecks. |
| do_not_use_when | The task is primarily application architecture pattern selection, general Python performance, security threat modeling, deployment, or observability. Load the corresponding specialist prompt instead or alongside this one. |
| related_prompts | poeaa_python_enterprise_patterns; high_performance_python; secure_python_app_security_threat_prevention; observable_python_logging_metrics_tracing; deployable_python_containers_orchestration_cicd |

## Index update rule

Do not edit the Prompt Navigation Index automatically during this audit session.
This file is only a candidate block for a later controlled index update.
