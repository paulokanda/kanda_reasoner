# AUDIT_REPORT__A013__data_aware_python_database_design_optimisation

## Audit metadata

- AUDIT_ID: A013
- PROMPT_FILENAME: 000 11 Data-Aware Python Database Design & Optimisation Prompt.md
- CANONICAL_ID: data_aware_python_database_design_optimisation
- DECLARED_VERSION: not declared in source
- DETECTED_TYPE: SPECIALIST_PROMPT
- DETECTED_GROUP: DATABASE / DATA_LAYER / PERFORMANCE_SUPPORT
- DETECTED_SCOPE: project_agnostic
- DECISION: KEEP
- STATUS_AFTER: audited_candidate

## Inventory

The prompt defines a Python database architect role focused on schema design, indexing,
query optimisation, migration strategy, connection pooling, replication, sharding,
partitioning, and SQL vs NoSQL choice.

It includes sections on:

- schema design;
- indexing strategy;
- EXPLAIN-based query optimisation;
- migrations and zero-downtime schema evolution;
- connection pooling;
- SQL vs NoSQL choice;
- read replicas and write scaling;
- performance monitoring;
- database optimisation toolkit;
- database anti-patterns;
- workflow and output format for database-related responses.

## Scope and responsibility

SINGLE_RESPONSIBILITY_PASS: YES

This prompt owns database and persistence-layer design from the database perspective.
It should be loaded for tasks involving schemas, indexes, migrations, SQLAlchemy,
EXPLAIN plans, connection pools, read replicas, partitioning, sharding, caching strategy,
and database bottlenecks.

PROJECT_LEAKAGE_FOUND: NO

No project-specific path, package, governance file, or local environment value was found.

## Related prompt inspection

Related prompts inspected in the uploaded batch:

| Related prompt | Relationship | Decision |
|---|---|---|
| 000 6 Patterns of Enterprise Application Architecture by Martin Fowler.md | Close overlap around persistence patterns, repositories, Unit of Work, Data Mapper, CQRS | Complementary, not duplicate |
| 000 7 High Performance Python Prompt for AI Code Generation.md | Overlap around profiling, caching, batch operations, performance measurement | Complementary, not duplicate |
| 000 9 Secure Python App Security & Threat Prevention Prompt.md | Overlap around SQL injection prevention and parameterised queries | Complementary, not duplicate |
| 000 0 Kubernetes Up and Running.md | Overlap around migrations, deployment, production readiness | Complementary, not duplicate |
| 000 10 Observable Python Logging, Metrics & Tracing Prompt.md | Overlap around slow query logs, pg_stat_statements, Prometheus exporters | Complementary, not duplicate |

RELATED_PROMPT_CONTENT_REVIEWED: YES for the relevant uploaded prompts.

## Overlap analysis

The closest overlap is with the PoEAA prompt. The separation is clear:

- Data-Aware Python owns database-level correctness and performance: schema, indexes,
  SQL/NoSQL choice, EXPLAIN, migrations, connection pools, replicas, partitioning.
- PoEAA owns application architecture patterns around persistence and domain behavior:
  Repository, Unit of Work, Data Mapper, Identity Map, Domain Model, Service Layer,
  Offline Locks, and CQRS as an application-pattern escape valve.

The overlap with Security is narrow and appropriate: database prompts may mention
parameterised queries, but Security owns threat modeling and attack prevention.

The overlap with High Performance is appropriate: database performance is one domain-specific
performance area, while High Performance owns general Python profiling and optimization.

## Conflicts found

CONFLICTS_FOUND: NO

## Dissonant logic

DISSONANT_LOGIC_EXTRACTED: NO

No useful rule was found that clearly belongs elsewhere. The prompt can remain intact.

## Integration candidates

INTEGRATION_CANDIDATES_CREATED: NONE

## Navigation index effect

NAVIGATION_INDEX_EFFECT: ADD

Recommended route:

- Task family: database design, schema design, SQLAlchemy, migrations, indexes, slow queries,
  EXPLAIN, connection pools, SQL vs NoSQL, replicas, partitioning, sharding.
- Load prompt: data_aware_python_database_design_optimisation
- Related prompts: poeaa_python_enterprise_patterns, high_performance_python,
  secure_python_app_security_threat_prevention, observable_python_logging_metrics_tracing,
  deployable_python_containers_orchestration_cicd.

## Human decision required

HUMAN_DECISION_REQUIRED: NO

## Final audit recommendation

Keep this prompt as a specialist project-agnostic database prompt. Do not merge it with PoEAA
or High Performance. Its content is important enough to preserve unchanged. Add metadata later
only if the whole specialist prompt library receives a normalization pass.
