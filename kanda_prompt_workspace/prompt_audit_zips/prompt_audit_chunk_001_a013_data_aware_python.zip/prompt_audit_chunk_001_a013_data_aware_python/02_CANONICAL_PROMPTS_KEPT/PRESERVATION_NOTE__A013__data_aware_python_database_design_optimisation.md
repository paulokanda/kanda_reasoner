# PRESERVATION_NOTE__A013__data_aware_python_database_design_optimisation

Decision: KEEP

The prompt is preserved unchanged because it has clear specialist ownership and useful content.

Ownership:
- database schema design;
- indexing strategy;
- EXPLAIN-based query optimisation;
- Alembic migrations and zero-downtime database evolution;
- connection pooling;
- SQL vs NoSQL selection;
- read replicas, partitioning, and sharding;
- database anti-patterns and database-specific output format.

Reason for no update:
- No project leakage detected.
- No conflicting rule detected.
- No dissonant logic requiring extraction.
- Overlap with PoEAA, Security, Performance, Observability, and Deployment is complementary.

Future optional normalization:
- Add metadata header.
- Add explicit relationship notes to PoEAA and High Performance.
- Keep content intact unless a later library-wide style pass is approved.
