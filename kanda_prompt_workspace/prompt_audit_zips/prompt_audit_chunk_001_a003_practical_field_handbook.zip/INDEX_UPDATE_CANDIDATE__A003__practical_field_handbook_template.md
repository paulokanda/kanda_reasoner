# INDEX UPDATE CANDIDATE - A003 - practical_field_handbook_template

Audit ID: A003
Prompt ID: practical_field_handbook_template
Prompt filename: 000 1 a PRACTICAL FIELD HANDBOOK of.MD
Recommended status: audited_candidate after update
Load mode: on_request

## Add active route after update

| Trigger / task | Prompt to load | Why |
|---|---|---|
| Convert a book into a practical field handbook | practical_field_handbook_template | Produces essence, mental model, chapter notes, checklist, misconceptions, resources, and 30-day adoption plan. |
| Convert a paper, framework, or specification into practical learning notes | practical_field_handbook_template | The template is domain-adaptable through TITLE, AUTHOR, DOMAIN, MY LEVEL, and MY CONTEXT. |
| Create a practical study guide for a technical work | practical_field_handbook_template | Focuses on actionable rules, anti-patterns, and modern relevance. |

## Do not route for

| Task | Better prompt |
|---|---|
| Create a YouTube EEG course class | youtube_eeg_course_creator |
| Generate Python production code | relevant specialist coding prompt |
| Audit prompt files | prompt_audit_canon |
| Create deployment/infrastructure artifacts | deployable_python_containers_orchestration_cicd |

## Index editing rule

Do not edit the Prompt Navigation Index directly during this audit. Apply this block only in a separate controlled index-update session.
