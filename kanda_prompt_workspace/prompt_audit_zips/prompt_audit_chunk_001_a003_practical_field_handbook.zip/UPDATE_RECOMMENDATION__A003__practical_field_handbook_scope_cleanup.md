# UPDATE RECOMMENDATION - A003 - practical_field_handbook_scope_cleanup

Source prompt:
000 1 a PRACTICAL FIELD HANDBOOK of.MD

Canonical ID:
practical_field_handbook_template

Recommended action:
UPDATE

## Problem

The prompt has a useful generic template structure, but its MY CONTEXT example contains a specific user/project context about neurophysiology, qEEG apps, YouTube classes, Python learning, and prompt engineering.

This makes the prompt mixed-scope:
- generic handbook template
- user-specific qEEG course context

## Required cleanup

Replace the current MY CONTEXT block with neutral examples such as:

```text
MY CONTEXT:
- "I write Python backend APIs solo."
- "I am learning system design for a small production app."
- "I am a beginner using this material to build a practical learning roadmap."
```

Add a separate optional field:

```text
OPTIONAL PROJECT CONTEXT:
[Paste only if the handbook must be adapted to a specific project or audience.]
```

## Routing note to add

```text
Use this prompt when the task is to convert a book, paper, framework, or specification into a practical field handbook.
Do not use it for YouTube EEG class generation. For that, load youtube_eeg_course_creator.
```

## Pause protocol cleanup

Use one pause rule only:

```text
If the answer exceeds the comfortable output window, stop cleanly after completing the current section and print exactly:

-- PAUSED: ready for Section [N]. Reply GO to continue. --
```

Remove the alternate wording:

```text
can I continue?
```

## Human decision

Human decision required: NO for cleanup.
Human decision required: YES only if the human wants the prompt to remain deliberately qEEG-specific.
