# Prompt Audit Chunk 001 - A014 - Resilient Python

This package contains the audit artifacts and the real updated prompt file for A014.

Audited source file:
- 000 12 Resilient Python Error Handling, Retries & Circuit Breakers Prompt.md

Decision:
- UPDATE

Reason for update:
- The prompt has strong specialist ownership and should be preserved.
- Two code examples needed small correctness fixes:
  1. The timeout example had an except block with only a comment.
  2. The circuit breaker example mixed `requests` calls with `httpx.HTTPError` as the expected exception and omitted an explicit timeout.

Real prompt file included:
- 03_UPDATED_PROMPTS/000 12 Resilient Python Error Handling, Retries & Circuit Breakers Prompt.md

No integration candidates were created.
