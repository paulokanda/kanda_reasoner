# AUDIT REPORT - A014 - Resilient Python

## Audit metadata

AUDIT_ID: A014
PROMPT_FILENAME: 000 12 Resilient Python Error Handling, Retries & Circuit Breakers Prompt.md
CANONICAL_ID: resilient_python_error_handling_retries_circuit_breakers
DECLARED_VERSION: not declared
SCOPE: project_agnostic
TYPE: SPECIALIST_PROMPT
SINGLE_RESPONSIBILITY_PASS: YES
PROJECT_LEAKAGE_FOUND: NO
STATUS_AFTER: audited_candidate after update
RECOMMENDED_DECISION: UPDATE
DECISION_GATE: CLEAR
HUMAN_DECISION_REQUIRED: NO

## Responsibility

This prompt owns Python resilience engineering: error handling strategy, timeouts, retries, exponential backoff, jitter, circuit breakers, bulkheading, graceful degradation, idempotency, dependency health checks, and resilience-oriented monitoring recommendations.

## Related prompt inspection

Related prompts inspected conceptually from the uploaded chunk:

- 000 8 Python Testing with pytest (Brian Okken) Prompt.md
- 000 9 Secure Python App Security & Threat Prevention Prompt.md
- 000 10 Observable Python Logging, Metrics & Tracing Prompt.md
- 000 0 Kubernetes Up and Running.md
- 000 13 Interface Python REST, GraphQL & API Design Prompt.md
- 000 16 Configurable Python Configuration Management & Feature Flags Prompt.md

Overlap decision: complementary, not duplicate.

## Overlap analysis

| Related prompt | Relationship | Ownership boundary |
|---|---|---|
| Testing | Complementary | Testing verifies resilience behavior; Resilience defines failure-handling patterns. |
| Security | Complementary | Security prevents attacks; Resilience survives dependency and runtime failures. |
| Observability | Complementary | Observability instruments retries, circuit state, and fallback events; Resilience defines those behaviors. |
| Deployment | Complementary | Deployment owns platform health checks and rollout; Resilience owns application-level failure survival. |
| API Design | Complementary | API Design owns interface semantics; Resilience owns idempotency and retry-safe mutations. |
| Configuration | Complementary | Configuration owns externally managed timeout/retry values; Resilience owns how those values are used safely. |

## Findings

The prompt is valuable and should be preserved. However, two examples needed correction:

1. The timeout example had an `except` block containing only a comment, which would be invalid if copied into real Python code.
2. The circuit breaker example used `requests.post(...)` but configured `expected_exception=httpx.HTTPError`. The corrected version uses `requests.RequestException`, imports `requests`, and adds an explicit request timeout.

## Dissonant logic

DISSONANT_LOGIC_EXTRACTED: NO

No useful logic was found that belongs in another prompt.

## Integration candidates

None.

## Final audit recommendation

Keep the prompt as a Resilient Python specialist prompt after applying the small code-example corrections. Do not merge it into Security, Observability, Deployment, API Design, or Testing.
