# UPDATE RECOMMENDATION - A014 - Resilient Python

Decision: UPDATE

## Required corrections applied

### 1. Timeout example

The original timeout example had an `except httpx.TimeoutException:` branch with only a comment.

Correction applied:
- Catch `httpx.TimeoutException as exc`.
- Add an explicit `raise RuntimeError(...) from exc` placeholder to make the snippet syntactically valid and behaviorally clear.

### 2. Circuit breaker example

The original circuit breaker example mixed `requests.post(...)` with `expected_exception=httpx.HTTPError` and did not import `requests`.

Correction applied:
- Import `requests`.
- Use `expected_exception=requests.RequestException`.
- Add an explicit `timeout=10.0`.
- Add a small docstring and type hints.

## Content preservation

No major resilience content was removed. The specialist ownership remains intact.
