# INDEX UPDATE CANDIDATE - A014 - Resilient Python

Do not edit the Prompt Navigation Index directly during this audit. Use this as a candidate block for a later controlled index update.

## Suggested active route

PROMPT_ID: resilient_python_error_handling_retries_circuit_breakers
FILENAME: 000 12 Resilient Python Error Handling, Retries & Circuit Breakers Prompt.md
CLASSIFICATION: SPECIALIST_PROMPT
STATUS: audited_candidate
LOAD_MODE: on_request

USE_WHEN:
- The task involves retries, timeouts, circuit breakers, bulkheading, graceful degradation, idempotency, dependency health checks, failure handling, or partial outage survival.

RELATED_PROMPTS:
- testing_python_pytest
- secure_python_app_security_threat_prevention
- observable_python_logging_metrics_tracing
- deployable_python_containers_orchestration_cicd
- interface_python_rest_graphql_api_design
- configurable_python_configuration_management_feature_flags

INDEX_EFFECT: ADD_OR_UPDATE_ACTIVE_ROUTE_AFTER_HUMAN_REVIEW
