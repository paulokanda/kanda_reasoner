# Update Recommendation — A024

## Recommendation

Use the updated prompt file in `03_UPDATED_PROMPTS` as the canonical active version.

## Why update instead of preserve unchanged?

The original prompt is strong, but two small clarifications reduce future ambiguity:

1. `assert` should not be treated as user-input validation. External/user validation should use explicit exceptions.
2. "Commit early, commit often" should not be interpreted as permission for the AI to run VCS commits automatically.

## Replacement Target

Replace or supersede:

`000 22 The Pragmatic Programmer by Andrew Hunt & David Thomas.md`

with:

`03_UPDATED_PROMPTS/000 22 The Pragmatic Programmer by Andrew Hunt & David Thomas.md`
