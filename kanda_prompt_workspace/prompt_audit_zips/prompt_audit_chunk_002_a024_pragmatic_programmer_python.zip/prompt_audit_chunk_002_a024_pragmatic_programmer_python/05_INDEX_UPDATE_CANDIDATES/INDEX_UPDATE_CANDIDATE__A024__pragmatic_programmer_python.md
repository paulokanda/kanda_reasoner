# Index Update Candidate — A024 — Pragmatic Programmer Python

## Proposed Entry

- **Prompt ID:** A024_PRAGMATIC_PROGRAMMER_PYTHON
- **File:** `000 22 The Pragmatic Programmer by Andrew Hunt & David Thomas.md`
- **Status:** active / audited_candidate_after_update
- **Classification:** SPECIALIST_PROMPT
- **Use when:** The task needs pragmatic engineering judgment, trade-off selection, DRY/orthogonality discipline, tracer bullets, development automation, design-by-contract framing, or professional coding habits.
- **Do not use as:** A replacement for specialist prompts that own detailed mechanisms, such as Security, Testing, Clean Architecture, Configurable Python, SRE, or Peopleware.
- **Related prompts:** Clean Code, Clean Architecture, Refactoring, Testing, Configurable Python, SRE, Peopleware.

## Routing Rule

Load this prompt when the user asks for broad engineering judgment, practical coding strategy, or workflow discipline across more than one technical area.
