# Audit Report — A024 — Pragmatic Programmer Python

## Source

`000 22 The Pragmatic Programmer by Andrew Hunt & David Thomas.md`

## Decision

UPDATE

## Classification

SPECIALIST_PROMPT

## Status

`audited_candidate_after_update`

## Reasoning

The prompt is valuable and should remain active. It provides pragmatic engineering discipline across responsibility, DRY, orthogonality, tracer bullets, deliberate programming, design by contract, crash-early behavior, configuration, automation, testing, documentation, and practical trade-offs.

## Ownership

This prompt owns pragmatic decision-making and general craftsmanship. It should not replace specialist prompts for security, testing, architecture, refactoring, observability, configuration, or SRE mechanics.

## Updates Applied

1. Added metadata frontmatter.
2. Added explicit ownership boundary.
3. Clarified design-by-contract guidance so external/user input uses explicit exceptions, while `assert` is reserved for internal programmer invariants.
4. Clarified that VCS commits are a workflow recommendation and must not be executed by the AI without authorization.
5. Preserved the original pragmatic workflow and development-environment automation add-on.

## Integration Candidates

None.

## Final Recommendation

Keep as an active specialist prompt. Use it when the user needs pragmatic trade-offs, general engineering judgment, automation discipline, and workflow habits across the Python development lifecycle.
