# INTEGRATION_CANDIDATE_LEDGER

Status: Active ledger for prompt-audit integration candidates
Use: Track integration candidate files created during prompt audits.

This ledger prevents useful extracted prompt logic from becoming orphaned.

Each integration candidate must have one Markdown file and one row in this ledger.

## Ledger

| IC_ID | source_prompt | target_prompt | filename | status | human_decision_required | date_created | notes |
|---|---|---|---|---|---|---|---|
| IC_ID | source_prompt | target_prompt | filename | pending_integration | YES/NO | YYYY-MM-DD | notes |

## Status values

| Status | Meaning |
|---|---|
| pending_integration | Candidate exists but has not been reviewed for insertion. |
| accepted_for_integration | Human accepted candidate for future insertion. |
| rejected | Human rejected candidate. |
| inserted | Candidate was inserted into target prompt through controlled integration. |
| superseded | Candidate was replaced by a newer candidate or rule. |
| stale | Candidate needs review because it remained unresolved across later audit sessions. |

## Required rule

Before any prompt is promoted from audited_candidate to active, integration candidates targeting that prompt should be resolved, rejected, or explicitly deferred by the human.
