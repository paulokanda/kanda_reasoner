# ACTIVE PROJECT FREEZE CONTEXT

Generated: `2026-06-21T00:00:17.194985Z`
Project root: `E:\kanda_reasoner`
Freeze memory source: `project_freeze_after_update/frozen_features_memory`
Freeze context status: `OK`
Index entries: `254`
Entry files: `254`
Active/non-superseded entries: `253`
Source fingerprint: `efabc2667e0f3abc66ae6d1039129faddb3fb9db53191ff1ad94338c4eb9f025`

## Purpose

This generated startup file is the AI access channel for project-specific frozen
feature memory at the beginning of a programming interaction.

This file is a generated exposure copy only.  The source of truth remains:

```text
<active_project_root>/project_freeze_after_update/frozen_features_memory/
```

## Compact freeze report

```text
FREEZE_MEMORY_STATUS: OK
CANONICAL RULE: project_freeze_ledger is reusable freeze engine logic; active freeze memory belongs only to the selected project's project_freeze_after_update/frozen_features_memory.
READ_ONLY_EXPOSURE: this report did not repair, regenerate, or mutate freeze_index.json, freeze entries, or files_to_send_ai.
Generated at UTC: 2026-06-21T00:00:17+00:00
Project root: E:\kanda_reasoner
Freeze memory: E:\kanda_reasoner\project_freeze_after_update\frozen_features_memory
Freeze index: E:\kanda_reasoner\project_freeze_after_update\frozen_features_memory\freeze_index.json
Entries folder: E:\kanda_reasoner\project_freeze_after_update\frozen_features_memory\entries
AI-send folder: E:\kanda_reasoner\project_freeze_after_update\files_to_send_ai
Index entries: 254
Entry files: 254
Active/non-superseded entries: 253

FREEZE IDS:
- freeze-20260612-phase7a-v24
- freeze-20260612-project-freeze-ledger-v1
- freeze-20260612-project-freeze-ledger-v18
- freeze-20260612-project-freeze-ledger-v19-structured-entries
- freeze-20260612-project-freeze-ledger-v20-freeze-index
- freeze-20260612-project-freeze-ledger-v22-final-clean-ai-send-tools
- freeze-20260613-freeze-after-update-bom-index-tolerance-v1
- freeze-20260613-freeze-after-update-generator-cache-rule-v3
- freeze-20260613-freeze-after-update-generator-delivery-commands-v2
- freeze-20260613-freeze-after-update-tab-help-layout-v1
- freeze-20260613-freeze-feature-after-update-v1
- freeze-20260613-project-freeze-ledger-blueprint-only-cleanup-v1
- freeze-20260613-startup-patch-request-routing-logic-v4
- freeze-20260614-freeze-memory-exposure-cli-v1
- freeze-20260614-startup-kernel-auditor-dynamic-delivery-v1
- freeze-20260614-t9t013-prompt-authoring-lifecycle-routing-v1
- freeze-20260615-cooperative-implementation-methodology-v1
- freeze-20260615-freeze-feature-after-update-local-freeze-workflow-v1
- freeze-20260615-phase2-conditional-context-rubric-v1
- freeze-20260615-routing-index-escalation-and-staleness-v1
- freeze-20260616-freeze-code-intake-prompt-routing-v1
- freeze-20260616-freeze-feature-after-update-local-freeze-workflow-v1
- freeze-20260616-freeze-form-autofill-stale-sidecar-selection-repair-v1
- freeze-20260616-freeze-formulary-current-feature-autofill-regression-v1
- freeze-20260616-freeze-hint-intake-box-v1
- freeze-20260616-freeze-hint-preserve-local-validation-v1
- freeze-20260616-freeze-hint-sidecar-delivery-contract-v1
- freeze-20260616-freeze-hint-validation-evidence-merge-v1
- freeze-20260616-freeze-hint-windows-temp-cleanup-tolerance-v1
- freeze-20260616-phase-2-prompt-call-accuracy-routing-matrix-v1
- freeze-20260616-pre-output-contract-gates-v1
- freeze-20260616-rg-028-exact-context-expansion-v2
- freeze-20260616-rg-029-startup-stale-filename-override-v1
- freeze-20260616-routing-signal-scorer-manual-pilots-v1
- freeze-20260616-routing-signal-scorer-v1-advisory
- freeze-20260616-routing-signal-scorer-v1-diagnostic
- freeze-20260616-routing-signal-scorer-v2-similarity-design
- freeze-20260616-routing-signal-scorer-v2-similarity-test-corpus
- freeze-20260617-freeze-hint-autofill-state-machine-tests-v1
- freeze-20260617-freeze-hint-consumed-newer-scan-continuation-v1
- ... 214 more freeze IDs hidden by compact limit

FREEZE ENTRY SUMMARY:
- freeze-20260612-phase7a-v24 | title=untitled | status=frozen | box=kanda_prompt_workspace/startup_delivery_system | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260612-phase7a-v24.md
- freeze-20260612-project-freeze-ledger-v1 | title=untitled | status=superseded | box=project_freeze_ledger | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260612-project-freeze-ledger-v1.md | superseded_by=freeze-20260612-project-freeze-ledger-v18
- freeze-20260612-project-freeze-ledger-v18 | title=untitled | status=frozen | box=project_freeze_ledger | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260612-project-freeze-ledger-v18.md
- freeze-20260612-project-freeze-ledger-v19-structured-entries | title=untitled | status=frozen | box=project_freeze_ledger/structured_entries | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260612-project-freeze-ledger-v19-structured-entries.md
- freeze-20260612-project-freeze-ledger-v20-freeze-index | title=untitled | status=frozen | box=project_freeze_ledger/freeze_index | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260612-project-freeze-ledger-v20-freeze-index.md
- freeze-20260612-project-freeze-ledger-v22-final-clean-ai-send-tools | title=untitled | status=frozen | box=project_freeze_ledger/final_clean_ai_send_tools | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260612-project-freeze-ledger-v22-final-clean-ai-send-tools.md
- freeze-20260613-freeze-after-update-bom-index-tolerance-v1 | title=untitled | status=frozen | box=project_freeze_ledger/freeze_tools + project_freeze_after_update/frozen_features_memory | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-freeze-after-update-bom-index-tolerance-v1.md
- freeze-20260613-freeze-after-update-generator-cache-rule-v3 | title=untitled | status=frozen | box=project_freeze_ledger | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-freeze-after-update-generator-cache-rule-v3.md
- freeze-20260613-freeze-after-update-generator-delivery-commands-v2 | title=untitled | status=frozen | box=freeze_after_update | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-freeze-after-update-generator-delivery-commands-v2.md
- freeze-20260613-freeze-after-update-tab-help-layout-v1 | title=untitled | status=frozen | box=freeze_after_update_gui | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-freeze-after-update-tab-help-layout-v1.md
- freeze-20260613-freeze-feature-after-update-v1 | title=untitled | status=frozen | box=freeze_after_update | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-freeze-feature-after-update-v1.md
- freeze-20260613-project-freeze-ledger-blueprint-only-cleanup-v1 | title=untitled | status=frozen | box=project_freeze_ledger | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-project-freeze-ledger-blueprint-only-cleanup-v1.md
- freeze-20260613-startup-patch-request-routing-logic-v4 | title=untitled | status=frozen | box=kanda_prompt_workspace/startup_routing_kernel | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-startup-patch-request-routing-logic-v4.md
- freeze-20260614-freeze-memory-exposure-cli-v1 | title=untitled | status=frozen | box=project_freeze_ledger/freeze_memory_dynamic_exposure_bridge | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260614-freeze-memory-exposure-cli-v1.md
- freeze-20260614-startup-kernel-auditor-dynamic-delivery-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/startup_kernel_auditor_and_dynamic_delivery | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260614-startup-kernel-auditor-dynamic-delivery-v1.md
- freeze-20260614-t9t013-prompt-authoring-lifecycle-routing-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_authoring_routing_kernel | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260614-t9t013-prompt-authoring-lifecycle-routing-v1.md
- freeze-20260615-cooperative-implementation-methodology-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/03_governance_freeze_and_handoff + prompt routing indexes + startup delivery | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260615-cooperative-implementation-methodology-v1.md
- freeze-20260615-freeze-feature-after-update-local-freeze-workflow-v1 | title=untitled | status=frozen | box=project_freeze_ledger/freeze_tools + kanda_reasoner_app/freeze_after_update + kanda_reasoner_app/freeze_after_update_gui + startup freeze context channel | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260615-freeze-feature-after-update-local-freeze-workflow-v1.md
- freeze-20260615-phase2-conditional-context-rubric-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_library/ROUTING_TESTS/PHASE_2_PROMPT_CALL_ACCURACY + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation + startup delivery | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260615-phase2-conditional-context-rubric-v1.md
- freeze-20260615-routing-index-escalation-and-staleness-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_library/ROUTING + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation + startup delivery | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260615-routing-index-escalation-and-staleness-v1.md
- freeze-20260616-freeze-code-intake-prompt-routing-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/03_governance_freeze_and_handoff + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/02_prompt_routing_and_indexing + kanda_prompt_workspace/prompt_tools + first_AI_deliver + selected active project/project_freeze_after_update/freeze_hint_intake | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-code-intake-prompt-routing-v1.md
- freeze-20260616-freeze-feature-after-update-local-freeze-workflow-v1 | title=untitled | status=frozen | box=project_freeze_ledger/freeze_tools + kanda_reasoner_app/freeze_after_update + kanda_reasoner_app/freeze_after_update_gui + startup freeze context channel | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-feature-after-update-local-freeze-workflow-v1.md
- freeze-20260616-freeze-form-autofill-stale-sidecar-selection-repair-v1 | title=untitled | status=frozen | box=kanda_reasoner_app/freeze_hint_intake + tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-form-autofill-stale-sidecar-selection-repair-v1.md
- freeze-20260616-freeze-formulary-current-feature-autofill-regression-v1 | title=untitled | status=frozen | box=unknown box | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-formulary-current-feature-autofill-regression-v1.md
- freeze-20260616-freeze-hint-intake-box-v1 | title=untitled | status=frozen | box=kanda_reasoner_app/freeze_hint_intake + kanda_reasoner_app/freeze_after_update_gui + project_freeze_after_update/freeze_hint_intake | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-hint-intake-box-v1.md
- freeze-20260616-freeze-hint-preserve-local-validation-v1 | title=untitled | status=frozen | box=kanda_reasoner_app/freeze_hint_intake + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/03_governance_freeze_and_handoff + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation + startup delivery guardrails + selected active project/project_freeze_after_update/freeze_hint_intake | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-hint-preserve-local-validation-v1.md
- freeze-20260616-freeze-hint-sidecar-delivery-contract-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation + patch ZIP delivery metadata + startup routing kernel | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-hint-sidecar-delivery-contract-v1.md
- freeze-20260616-freeze-hint-validation-evidence-merge-v1 | title=untitled | status=frozen | box=kanda_reasoner_app/freeze_hint_intake + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/03_governance_freeze_and_handoff + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation + startup delivery guardrails + selected active project/project_freeze_after_update/freeze_hint_intake | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-hint-validation-evidence-merge-v1.md
- freeze-20260616-freeze-hint-windows-temp-cleanup-tolerance-v1 | title=untitled | status=frozen | box=tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-freeze-hint-windows-temp-cleanup-tolerance-v1.md
- freeze-20260616-phase-2-prompt-call-accuracy-routing-matrix-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace startup routing, prompt-library governance, and Freeze Feature After Update routing behavior | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-phase-2-prompt-call-accuracy-routing-matrix-v1.md
- freeze-20260616-pre-output-contract-gates-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/03_governance_freeze_and_handoff + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation + kanda_prompt_workspace/prompt_tools + first_AI_deliver + selected active project/project_freeze_after_update/freeze_hint_intake | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-pre-output-contract-gates-v1.md
- freeze-20260616-rg-028-exact-context-expansion-v2 | title=untitled | status=frozen | box=kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation + kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/02_prompt_routing_and_indexing + kanda_prompt_workspace/prompt_library/ROUTING + startup routing kernel | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-rg-028-exact-context-expansion-v2.md
- freeze-20260616-rg-029-startup-stale-filename-override-v1 | title=untitled | status=frozen | box=kanda_prompt_workspace/startup_routing_kernel + kanda_prompt_workspace/first_AI_deliver + kanda_prompt_workspace/prompt_tools | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-rg-029-startup-stale-filename-override-v1.md
- freeze-20260616-routing-signal-scorer-manual-pilots-v1 | title=untitled | status=frozen | box=tests + kanda_reasoner_app/routing_signal_scorer | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-routing-signal-scorer-manual-pilots-v1.md
- freeze-20260616-routing-signal-scorer-v1-advisory | title=untitled | status=frozen | box=kanda_reasoner_app/routing_signal_scorer + tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-routing-signal-scorer-v1-advisory.md
- freeze-20260616-routing-signal-scorer-v1-diagnostic | title=untitled | status=frozen | box=kanda_reasoner_app/routing_signal_scorer + tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-routing-signal-scorer-v1-diagnostic.md
- freeze-20260616-routing-signal-scorer-v2-similarity-design | title=untitled | status=frozen | box=kanda_reasoner_app/routing_signal_scorer/design + tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-routing-signal-scorer-v2-similarity-design.md
- freeze-20260616-routing-signal-scorer-v2-similarity-test-corpus | title=untitled | status=frozen | box=kanda_reasoner_app/routing_signal_scorer/design + tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260616-routing-signal-scorer-v2-similarity-test-corpus.md
- freeze-20260617-freeze-hint-autofill-state-machine-tests-v1 | title=untitled | status=frozen | box=kanda_reasoner_app/freeze_hint_intake + tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260617-freeze-hint-autofill-state-machine-tests-v1.md
- freeze-20260617-freeze-hint-consumed-newer-scan-continuation-v1 | title=untitled | status=frozen | box=kanda_reasoner_app/freeze_hint_intake + tests | entry=project_freeze_after_update/frozen_features_memory/entries/freeze-20260617-freeze-hint-consumed-newer-scan-continuation-v1.md
- ... 214 more entries hidden by compact limit

PROTECTED PATHS:
- kanda_prompt_workspace/prompt_tools/sync_startup_routing_kernel_pack.py
- kanda_prompt_workspace/prompt_tools/STARTUP_ROUTING_KERNEL_SOURCES.json
- kanda_prompt_workspace/first_AI_deliver/
- project_freeze_ledger/readme_project_freeze_ledger.md
- project_freeze_ledger/project_frozen_implemented_steps.md
- project_freeze_ledger/entries/
- project_freeze_ledger/send_to_ai_when_freezing_feature.md
- project_freeze_ledger/USER_READ_THIS_TO_UNDERSTAND_HOW_TO_FREEZE_FEATURE.md
- project_freeze_ledger/freeze_tools/repair_v19_structured_entries.py
- project_freeze_ledger/freeze_tools/validate_freeze_entry_frontmatter.py
- project_freeze_ledger/freeze_tools/build_freeze_index.py
- project_freeze_ledger/freeze_index.json
- project_freeze_ledger/freeze_tools/
- project_freeze_ledger/freeze_tools/freeze_after_update_generator.py
- project_freeze_after_update/files_to_send_ai/what_to_say_to_ai_freeze_feature.md
- project_freeze_after_update/frozen_features_memory/
- kanda_reasoner_app/freeze_after_update/blueprint_adapter.py
- kanda_reasoner_app/freeze_after_update/send_pack_builder.py
- kanda_reasoner_app/freeze_after_update/box_bootstrapper.py
- project_freeze_after_update/files_to_send_ai/
- kanda_reasoner_app/freeze_after_update_gui/freeze_after_update_tab.py
- project_freeze_after_update/frozen_features_memory/entries/freeze-20260613-freeze-after-update-tab-help-layout-v1.md
- kanda_reasoner_app/freeze_after_update/
- kanda_reasoner_app/freeze_after_update_gui/
- kanda_reasoner_app/reasoner_tools_gui_shell/tool_specs.py
- tools/validate_freeze_after_update_box.py
- project_freeze_ledger/README.md
- kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation/ai_prompt_request_canon.md
- kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/02_prompt_routing_and_indexing/prompt_navigation_index.md
- kanda_prompt_workspace/prompt_library/ROUTING/GROUP_ASSIMILATION_INDEX.md
- kanda_prompt_workspace/first_AI_deliver/first_prompts_to_ai.zip
- kanda_prompt_workspace/first_AI_deliver/paste_after_uploading_startup_zip.md
- kanda_prompt_workspace/first_AI_deliver/paste_if_modify_startup_delivery.md
- project_freeze_ledger/freeze_tools/expose_freeze_memory.py
- project_freeze_after_update/frozen_features_memory/freeze_index.json
- project_freeze_after_update/frozen_features_memory/project_frozen_implemented_steps.md
- project_freeze_after_update/frozen_features_memory/entries/freeze-20260614-freeze-memory-exposure-cli-v1.md
- kanda_prompt_workspace/prompt_tools/audit_startup_candidates.py
- kanda_prompt_workspace/prompt_tools/STARTUP_ROUTING_KERNEL_SOURCES_UPDATE_CANDIDATE.md
- kanda_prompt_workspace/prompt_library/ACTIVE_PROMPTS/01_session_start_and_navigation/daily_patch_delivery_guardrails.md
- ... 428 more protected paths hidden by compact limit

DO-NOT-REGRESS RULES:
- Preserve source-map based startup delivery.
- Keep stable 00_START_HERE_FOR_AI.md inside the startup ZIP.
- Keep startup-delivery maintenance file outside the normal startup ZIP.
- Historical baseline retained for audit trail.
- Superseded by the dynamic-path v18 freeze ledger baseline.
- Do not reintroduce hardcoded local absolute paths.
- Keep human guide and AI helper separate.
- Keep Markdown canonical until generated index tooling is implemented.
- Keep structured frontmatter at the top of freeze entries.
- Keep Markdown entries canonical until generated index tooling is implemented.
- Do not create freeze_index.json in this frozen box.
- Do not create protected path checker in this frozen box.
- Keep Markdown entries as canonical source.
- Keep freeze_index.json generated from structured freeze entries.
- Do not edit freeze_index.json manually.
- Keep freeze_tools as the final clean permanent tool folder.
- Permanent freeze_tools scripts are build_freeze_index.py, check_protected_paths.py, and files_needed_for_freezing.py.
- Do not re-add validate_*.py as permanent freeze_tools files.
- Do not keep one-time apply or cleanup scripts in freeze_tools after maintenance succeeds.
- Keep AI-send packs generated and replaceable; terminal validation logs are the validation evidence.
- Keep Markdown freeze entries canonical and freeze_index.json generated.
- Future freeze patch instructions must not classify Python runtime/cache artifacts as persistent architecture violations.
- __pycache__, .pyc, __pypackages__, .pytest_cache, .mypy_cache, .ruff_cache, and similar runtime/cache outputs may be removed opportunistically.
- Validation must not fail merely because Python recreated runtime/cache artifacts during py_compile, import, or test execution.
- Persistent architecture validation should target source files, generated project memory, generated delivery artifacts, and documented box boundaries only.
- The cache/runtime tolerance rule is generated into project_freeze_after_update/files_to_send_ai/what_to_say_to_ai_freeze_feature.md for future freeze requests.
- The Freeze Feature After Update instruction generator belongs in KANDA Reasoner's blueprint freeze box: project_freeze_ledger/freeze_tools/.
- The GUI/app box must remain a controller/adapter and must not own canonical instruction-template logic.
- Generated instructions must be recreated into each selected project's project_freeze_after_update/files_to_send_ai/ folder.
- The generated what_to_say_to_ai_freeze_feature.md must require ZIP delivery, install code, and validation code in one AI response.
- Delivery ZIP paths must be derived from PROJECT_ROOT drive root, not hardcoded to E: and not assumed to be inside the project root.
- PowerShell validation must set PYTHONPATH before project imports, must not use Bash heredoc syntax, and must not validate guessed/private result attributes.
- Freeze Feature After Update tab keeps a two-column symmetrical layout: left for active project, status/actions, and generated output; right for the log window.
- The tab exposes the dynamic files_to_send_ai path for the active project and includes helpers to open/copy that path.
- The tab provides a read-only floating viewer for what_to_say_to_ai_freeze_feature.md with Copy Complete Text and Close actions.
- The tab includes a top-right Help button opening a practical, read-only help window.
- Generated what_to_say_to_ai_freeze_feature.md must not be edited manually; if the content needs change, update the blueprint generator instead.
- Preserve the Freeze Feature After Update tab as the human-facing way to generate AI-send freeze files after a project update.
- Project-specific freeze memory must live inside <project_root>/project_freeze_after_update/frozen_features_memory/.
- Generated upload files must live inside <project_root>/project_freeze_after_update/files_to_send_ai/.
- ... 1991 more rules hidden by compact limit

AI OPERATING INSTRUCTION:
- Treat this as a current compact summary of the selected project's frozen memory.
- For implementation touching frozen behavior, request the specific full freeze-*.md entry when the summary is not enough.
- Do not treat project_freeze_ledger as active project memory.
- Do not overwrite frozen behavior without explicit governed update and validation evidence.
- If status is not OK, resolve or explicitly account for the warning before implementation.
```

## Post-validation freeze awareness rule

When you help implement, install, or validate a project change, check this
freeze context before concluding the work.

If the change is installed and validation evidence is clean, and the change
creates or updates governed behavior, protected paths, startup delivery,
prompt-library behavior, freeze workflow, or architecture-sensitive logic, tell
the user:

```text
This validated feature should now be considered for freeze-memory update.
```

Offer the user these choices:

1. Freeze it locally through the Freeze Feature After Update tab.
2. Ask AI to help prepare the freeze entry.

Do not silently assume the feature is frozen.
Do not update freeze memory without explicit human approval.
Do not treat project_freeze_ledger as active project memory.
