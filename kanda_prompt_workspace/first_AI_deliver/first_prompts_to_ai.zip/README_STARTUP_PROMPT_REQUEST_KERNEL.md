# Startup Prompt Request Kernel Upload Pack

Certificate: `20260621_000017Z`
Generated: `2026-06-21T00:00:17.194985Z`
ZIP: `first_prompts_to_ai.zip`

## Purpose

This ZIP is a generated human-upload convenience pack for the KANDA prompt system.
It contains separated Markdown startup files that help an AI route tasks and request the correct prompt files at the correct time.

## Canonical source rule

The files inside this ZIP are generated copies.
Do not edit them as canonical source.
Edit the original files under `prompt_library/`, then regenerate or verify this ZIP with:

```powershell
python .\prompt_tools\sync_startup_routing_kernel_pack.py --ensure-sync --yes
```

Use `--sync --yes` when you intentionally want to force regeneration even if the pack is already in sync.

## Upload workflow

1. Upload this ZIP to ChatGPT.
2. Open `paste_after_first_prompts_to_ai.md` in `first_AI_deliver/`.
3. Paste the boot command into ChatGPT.
4. Wait for `STARTUP PACK LOAD CHECK`.
5. Only then provide the project task.

## Files

- `01_ai_prompt_request_canon.md` - Defines how AI must ask Kanda for missing prompt groups, folder cards, specialist prompts, and missing behavior gates.
- `02_prompt_navigation_index.md` - Provides the map from task types to prompt groups and specialist prompt candidates.
- `03_GROUP_ASSIMILATION_INDEX.md` - Summarizes the 12 prompt groups so AI can select the right group before requesting deeper prompts.
- `04_FOLDER_ASSIMILATION_CARDS_INDEX.md` - Indexes folder assimilation cards and helps AI request the correct folder card when needed.
- `05_start_of_day_master_stack.md` - Defines start-of-day/session startup flow and baseline session behavior.
- `06_session_start_upload_checklist.md` - Checklist for which context files should be present at session startup.
- `07_daily_patch_delivery_guardrails.md` - Defines daily patch delivery staging, root-cleanliness, terminal hygiene, and freeze-reminder guardrails.
- `08_handoff_at_end_of_work.md` - Defines mandatory end-of-work handoff behavior so long governed sessions resume safely in a later AI chat.
- `09_active_project_freeze_context.md` - Generated active-project freeze memory context and post-validation freeze-awareness rule for AI programming compliance.

## Integrity

See `STARTUP_PROMPT_REQUEST_KERNEL_MANIFEST.json` for source paths, hashes, generated filenames, and ZIP certificate data.
